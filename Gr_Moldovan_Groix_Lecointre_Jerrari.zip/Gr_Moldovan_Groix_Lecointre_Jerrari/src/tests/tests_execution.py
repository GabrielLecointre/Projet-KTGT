"""
Script d'exécution pour lancer les tests de comparaison des temps d'exécution
entre les implémentations BasePython et PandaPython pour les questions 1 et 2.

Chaque module lancé via `subprocess` exécute une comparaison entre deux méthodes
et affiche les résultats dans une interface Tkinter.
"""

import subprocess
import os

# Définir le répertoire où se trouvent les scripts de test
repertoire_test = r"src/tests"

# === Lancer le module de test pour la question 1 ===
nom_fichier_q1 = "compare_temps_execution_question1.py"
chemin_complet_q1 = os.path.join(repertoire_test, nom_fichier_q1)

# Exécution du script Python dans un sous-processus
subprocess.run(["python", chemin_complet_q1])

# === Lancer le module de test pour la question 2 ===
nom_fichier_q2 = "compare_temps_execution_question2.py"
chemin_complet_q2 = os.path.join(repertoire_test, nom_fichier_q2)

# Exécution du script Python dans un sous-processus
subprocess.run(["python", chemin_complet_q2])
