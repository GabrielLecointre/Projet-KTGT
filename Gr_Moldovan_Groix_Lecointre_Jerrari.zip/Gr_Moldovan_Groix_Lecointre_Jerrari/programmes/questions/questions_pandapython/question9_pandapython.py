# Ce programme Python donne les pays qui ont été médaillés
# dans le maximum d’éditions différentes des Jeux Olympiques.
# ATTENTION : CHANGER LE CHEMIN DU FICHIER SI BESOIN
import pandas
import os
import time

pandas.set_option("display.max_rows", 150)

# Lire les fichiers .csv avec la base de données (CHEMIN DU FICHIER)
BDJO = pandas.read_csv(os.path.join("donnees", "athlete_events.csv"))
pays = pandas.read_csv(os.path.join("donnees", "noc_regions.csv"))

debutchrono = time.time()

BDJOpaysmedailles = BDJO.dropna(subset=["Medal"])
# Je supprime les lignes sans médailles. Ne reste plus qu’or, argent et bronze.
BDJOpaysmedailles.drop(
    columns=[
        "Name",
        "Age",
        "Weight",
        "Team",
        "City",
        "Event",
        "ID",
        "Sex",
        "Height",
        "Year",
        "Sport",
        "Medal",
    ],
    inplace=True,
)
# Il ne reste plus que les trois colonnes NOC, Games, Season.
# paysmedailles = BDJOpaysmedailles.groupby('NOC')['Games'].nunique().reset_index()
BDJOpaysmedailles.drop_duplicates(keep="first", inplace=True)
# On ne garde qu’une seule donnée par pays pour une édition donnée.

pays_total = BDJOpaysmedailles.groupby("NOC").size().reset_index(name="Nb_JO")

# Compter le nombre de lignes pour chaque pays pour la saison Winter
pays_hiver = (
    BDJOpaysmedailles[BDJOpaysmedailles["Season"] == "Winter"]
    .groupby("NOC")
    .size()
    .reset_index(name="Nb_JO_H")
)

# Compter le nombre de lignes pour chaque pays pour la saison Summer
pays_ete = (
    BDJOpaysmedailles[BDJOpaysmedailles["Season"] == "Summer"]
    .groupby("NOC")
    .size()
    .reset_index(name="Nb_JO_E")
)

# set_index

# Fusionner les trois DataFrames pour avoir un tableau complet
paysmedailles = pandas.merge(pays_total, pays_ete, on="NOC", how="left")
paysmedailles = pandas.merge(paysmedailles, pays_hiver, on="NOC", how="left")
# jointure
paysmedailles = pandas.merge(
    paysmedailles,
    pays[["NOC", "region"]],
    on="NOC",
    how="left",
)

# Le tableau des pays est imparfait soit 4 corrections à la main :
# SGP = Singapore (manquant)
# HKG = Hong Kong à affecter à Hong Kong et non à China (2 délégations différentes)
# WIF = Indes occidentales à affecter à Jamaica et non à Trinidad (plus logique car
# plus peuplée et les médailles sont remportées par des Jamaïquains)
# GDR = Allemagne de l’Est affecté à East Germany (plus logique car période où
# Allemagne de l’Ouest a aussi sa délégation)

corrections = {
    "SGP": "Singapore",
    "HKG": "Hong Kong",
    "WIF": "Jamaica",
    "GDR": "East Germany",
}

paysmedailles["region"] = (
    paysmedailles["NOC"].map(corrections).fillna(paysmedailles["region"])
)

# On remplace les NaN par des zéros.
paysmedailles.fillna(0, inplace=True)

# On transforme les flottants en entiers.
paysmedailles[["Nb_JO", "Nb_JO_H", "Nb_JO_E"]] = paysmedailles[
    ["Nb_JO", "Nb_JO_H", "Nb_JO_E"]
].astype(int)

# On regroupe les pays suivants (ou leur prolongement historique) qui ont eu
# des médailles sous des codes différents selon les périodes, le nom de pays
# renvoyé par le tableau est identique et les données peuvent être sommées :
# ANZ = Australasie (soit Australie + Nouvelle-Zélande) affecté à Australia
# BOH et TCH = Bohême et Tchécoslovaquie (soit République tchèque et Slovaquie)
# affecté à Czech Republic (entité principale démographique)
# YUG et SCG = Yougoslavie (soit 7 pays) et Serbie-et-Monténégro (soit Serbie et
# Monténégro) affecté à Serbia (entité démographique principale)
# URS et EUN = Union soviétique (soit 15 pays, Jeux de 1988 et avant)
# et Équipe unifiée (12 pays, Jeux de 1992) affecté à Russia (son entité centrale)
# FRG = Allemagne de l’Ouest affecté à Germany
# WIF = Indes occidentales affecté à Jamaica
paysmedailles = (
    paysmedailles.groupby("region")[["Nb_JO", "Nb_JO_E", "Nb_JO_H"]].sum().reset_index()
)

# On calcule du nombre total d’éditions par type de Jeux Olympiques.
nb_total = BDJO["Games"].nunique()
nb_ete = BDJO[BDJO["Season"] == "Summer"]["Games"].nunique()
nb_hiver = BDJO[BDJO["Season"] == "Winter"]["Games"].nunique()

# On crée une ligne "TOTAL" au format DataFrame.
ligne_total = pandas.DataFrame(
    {
        "Nb_JO": [nb_total],
        "Nb_JO_E": [nb_ete],
        "Nb_JO_H": [nb_hiver],
        "region": "TOTAL",
    },
    index=["TOTAL"],
)

# On ajoute cette ligne au tableau "paysmedailles".
paysmedailles = pandas.concat([ligne_total, paysmedailles])

# Je renomme la colonne "region" en "délégation".
paysmedailles.rename(columns={"region": "délégation"}, inplace=True)
# Je supprime la colonne d'index qui était indésirable
# et je fais de la colonne "region" le nouvel index.
paysmedailles = paysmedailles.set_index("délégation")

# Je classe enfin les pays par ordre décroissant des Jeux où ils ont une médaille
# puis à nombre égal par ordre alphabétique.
paysmedailles_tri = paysmedailles.sort_values(
    by=["Nb_JO", "délégation"], ascending=[False, True]
)

# Afficher le résultat
print(paysmedailles_tri)
fichier_excel = "output/question_9/paysmedailles_tri.xlsx"
paysmedailles_tri.to_excel(fichier_excel)

finchrono = time.time()
tpsexe = finchrono - debutchrono
print("Le temps d’exécution du programme est de", tpsexe, "seconde(s).")
