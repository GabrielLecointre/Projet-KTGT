import csv
from collections import Counter
from openpyxl import Workbook
import os


def nb_medailles_athlete(nom, annee=None):
    fichier_csv = 'donnees/athlete_events.csv'
    donnees_filtrees = []

    with open(fichier_csv, newline='', encoding='utf-8') as csvfile:
        lecteur = csv.DictReader(csvfile)
        for ligne in lecteur:
            nom_athlete = ligne['Name']
            annee_jeu = int(ligne['Year'])
            evenement = ligne['Event']
            medaille = ligne['Medal']

            if nom.lower() in nom_athlete.lower():
                if annee is None or annee == annee_jeu:
                    donnees_filtrees.append({
                        'Year': annee_jeu,
                        'Name': nom_athlete,
                        'Event': evenement,
                        'Medal': medaille
                    })

    # Éviter les doublons exacts
    donnees_uniques = [dict(t) for t in {tuple(d.items()) for d in donnees_filtrees}]

    # Compter les médailles
    medailles = [d['Medal'] for d in donnees_uniques if d['Medal'] not in ('', 'NA')]
    compteur = Counter(medailles)
    total = sum(compteur.values())

    # Résumé
    resume = dict(compteur)
    resume['Total des médailles'] = total

    # Liste unique des noms trouvés
    noms_trouves = sorted({d['Name'] for d in donnees_uniques})

    # Nettoyage pour le nom de fichier
    nom_fichier_base = nom.strip().lower().replace(' ', '_')
    suffixe_annee = f"_{annee}" if annee else "_toutes_annees"
    nom_fichier = f"nb_medaille_{nom_fichier_base}{suffixe_annee}_pythonbase.xlsx"

    # Création fichier Excel
    wb = Workbook()

    # Onglet 1 : détails
    ws_details = wb.active
    ws_details.title = "Details"
    ws_details.append(['Year', 'Name', 'Event', 'Medal'])
    for d in donnees_uniques:
        ws_details.append([d['Year'], d['Name'], d['Event'], d['Medal']])

    # Onglet 2 : résumé
    ws_resume = wb.create_sheet(title="Résumé")
    ws_resume.append(['Médaille', 'Nombre'])
    for medaille, nb in resume.items():
        ws_resume.append([medaille, nb])

    # Vérifier si le répertoire output existe, sinon le créer
    output_dir = 'output/question_1'
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # Enregistrer le graphique dans le répertoire output
    graph_path = os.path.join(output_dir, nom_fichier)
    wb.save(graph_path)

    # Affichage console
    print(f"\nLe nombre de médailles des athlètes dont le nom contient '{nom}'"
          f"{' en ' + str(annee) if annee else ''} est : {total}")

    print("\nNoms des athlètes trouvés :")
    for n in noms_trouves:
        print(f"- {n}")


nb_medailles_athlete("jean")
