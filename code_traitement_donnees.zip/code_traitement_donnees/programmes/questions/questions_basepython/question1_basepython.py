'''
Question 1 (obligatoire)
Déterminez le nombre de médailles gagnées par Michael Phelps. Son nom complet
est Michael Fred Phelps, II.
'''
import csv
from collections import Counter
from openpyxl import Workbook
import os


def nb_medailles_athlete(nom, annee=None):
    """
    Calcule le nombre de médailles remportées par un athlète dont le nom
    contient une chaîne de caractères donnée, avec possibilité de filtrer
    par année. Les résultats sont enregistrés dans un fichier Excel
    contenant deux onglets (détails et résumé) et affichés dans la console.

    Parameters
    ----------
    nom : str
        Partie ou totalité du nom d'un athlète (insensible à la casse).

    annee : int, optionnel
        Année des jeux olympiques pour filtrer les résultats. Si None,
        toutes les années sont prises en compte.

    Returns
    -------
    None
        La fonction ne retourne rien mais enregistre un fichier Excel
        et affiche les résultats dans la console.

    Examples
    --------
    >>> nb_medailles_athlete("Michael Fred Phelps, II", 2008)
    Le nombre de médailles des athlètes dont le nom contient 'Michael Fred Phelps, II' en 2008 est : 8
    """

    # Chemin vers le fichier CSV contenant les données olympiques
    fichier_csv = 'donnees/athlete_events.csv'

    # Liste pour stocker les lignes correspondant aux critères
    donnees_filtrees = []

    # Ouvrir le fichier CSV en lecture
    with open(fichier_csv, newline='', encoding='utf-8') as csvfile:
        lecteur = csv.DictReader(csvfile)

        # Parcourir chaque ligne du fichier CSV
        for ligne in lecteur:
            nom_athlete = ligne['Name']
            annee_jeu = int(ligne['Year'])
            evenement = ligne['Event']
            medaille = ligne['Medal']

            # Vérifier si le nom de l'athlète contient le nom recherché
            if nom.lower() in nom_athlete.lower():
                # Vérifier l'année si précisée
                if annee is None or annee == annee_jeu:
                    donnees_filtrees.append({
                        'Year': annee_jeu,
                        'Name': nom_athlete,
                        'Event': evenement,
                        'Medal': medaille
                    })

    # Éliminer les doublons exacts dans les lignes sélectionnées
    donnees_uniques = [dict(t) for t in {tuple(d.items()) for d in donnees_filtrees}]

    # Extraire les médailles valides (exclure NA ou vides)
    medailles = [d['Medal'] for d in donnees_uniques if d['Medal'] not in ('', 'NA')]

    # Compter les occurrences de chaque type de médaille
    compteur = Counter(medailles)

    # Calcul du total des médailles
    total = sum(compteur.values())

    # Créer le résumé des médailles avec total
    resume = dict(compteur)
    resume['Total des médailles'] = total

    # Extraire les noms uniques des athlètes trouvés
    noms_trouves = sorted({d['Name'] for d in donnees_uniques})

    # Créer un nom de fichier propre pour l'enregistrement
    nom_fichier_base = nom.strip().lower().replace(' ', '_')
    suffixe_annee = f"_{annee}" if annee else "_toutes_annees"
    nom_fichier = f"nb_medaille_{nom_fichier_base}{suffixe_annee}_pythonbase.xlsx"

    # Créer un nouveau fichier Excel
    wb = Workbook()

    # Onglet "Details" avec les événements
    ws_details = wb.active
    ws_details.title = "Details"
    ws_details.append(['Year', 'Name', 'Event', 'Medal'])
    for d in donnees_uniques:
        ws_details.append([d['Year'], d['Name'], d['Event'], d['Medal']])

    # Onglet "Résumé" avec le comptage des médailles
    ws_resume = wb.create_sheet(title="Résumé")
    ws_resume.append(['Médaille', 'Nombre'])
    for medaille, nb in resume.items():
        ws_resume.append([medaille, nb])

    # Vérifier ou créer le répertoire de sortie
    output_dir = 'output/question_1'
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # Chemin complet vers le fichier Excel à sauvegarder
    graph_path = os.path.join(output_dir, nom_fichier)
    wb.save(graph_path)

    # Afficher les résultats dans la console
    print(f"\nLe nombre de médailles des athlètes dont le nom contient '{nom}'"
          f"{' en ' + str(annee) if annee else ''} est : {total}")

    print("\nNoms des athlètes trouvés :")
    for n in noms_trouves:
        print(f"- {n}")


nb_medailles_athlete("Michael Fred Phelps, II")
