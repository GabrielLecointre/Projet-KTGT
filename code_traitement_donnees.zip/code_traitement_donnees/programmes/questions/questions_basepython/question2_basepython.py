import csv

def compter_medailles_par_pays(annee, teams='all'):
    """
    Analyser les données des médailles obtenues lors des Jeux Olympiques pour
    une année donnée et enregistrer les résultats dans un fichier CSV.

    Cette fonction charge les données des athlètes
    (en supposant un fichier CSV avec des informations
    sur les événements, les équipes et les médailles),
    filtre les données pour une année spécifique,
    et calcule deux types de totaux de médailles :
    - Total supérieur (en comptabilisant les doublons de médailles
    pour une équipe donnée).
    - Total inférieur (en comptabilisant chaque médaille une seule fois
    par équipe et événement).
    Les résultats sont ensuite triés par le nombre total de médailles (supérieur),
    et enregistrés dans un fichier CSV.

    Parameters:
    -----------
    year : int
        L'année pour laquelle les résultats doivent être analysés
        (ex. 2008, 2016).

    team : str ou list, optionnel, par défaut 'all'
        Le ou les pays à inclure dans l'analyse. Si 'all', tous les pays
        seront inclus.
        Si une chaîne de caractères, seule l'équipe spécifiée sera incluse.
        Si une liste de chaînes de caractères, seules les équipes présentes
        dans cette liste seront prises en compte. Les équipes doivent être des
        noms exacts tels qu'ils apparaissent dans les données.

    Return:
    --------
    pd.DataFrame
        Un DataFrame contenant les résultats des médailles par équipe et type de médaille, avec
        les totaux supérieurs et inférieurs pour chaque équipe. Ce DataFrame est également
        enregistré dans un fichier CSV.

    Example:
    --------
    analyser_et_enregistrer_medailles(2016)
    analyser_et_enregistrer_medailles(2016, team='France')
    analyser_et_enregistrer_medailles(2016, team=['USA', 'China'])

    Notes:
    ------
    Le fichier CSV généré aura le nom suivant :
    - 'resultats_medailles_<year>_<team>.csv', où `<year>` est l'année et
    `<team>` est soit 'all_countries' (si 'all' est passé), soit un nom de
    pays (ou plusieurs séparés par des underscores).

    Exemples de colonnes dans le fichier CSV :
    - Gold_inf : Nombre de médailles d'or sans doublons.
    - Silver_inf : Nombre de médailles d'argent sans doublons.
    - Bronze_inf : Nombre de médailles de bronze sans doublons.
    - Gold_sup : Nombre de médailles d'or avec doublons.
    - Silver_sup : Nombre de médailles d'argent avec doublons.
    - Bronze_sup : Nombre de médailles de bronze avec doublons.
    - Total_inf : Total des médailles sans doublons.
    - Total_sup : Total des médailles avec doublons.

    Si un ou plusieurs pays spécifiés ne sont pas trouvés pour l'année donnée,
    un message d'erreur sera affiché et l'exécution sera arrêtée.
    """
    # Lire le fichier CSV
    with open('donnees/athlete_events.csv', 'r', encoding='utf-8') as donnees:
        lecteur = csv.reader(donnees)
        tableau = list(lecteur)

    # En-têtes pour identifier les colonnes
    header = tableau[0]
    data = tableau[1:]

    # Extraire les colonnes nécessaires : Team (6), Year (9), Event (13), Medal (14)
    medailles = []
    for ligne in data:
        team, year, event, medal = ligne[6], ligne[9], ligne[13], ligne[14]
        if medal in ['Gold', 'Silver', 'Bronze']:
            medailles.append([team, year, event, medal])

    # Filtrage par année
    medailles_annee = [ligne for ligne in medailles if ligne[1] == str(annee)]

    # Liste des pays disponibles
    pays_disponibles = sorted(set([ligne[0] for ligne in medailles_annee]))

    # Gestion du filtre de pays
    if teams != 'all':
        if isinstance(teams, str):
            teams = [teams]
        inconnus = [t for t in teams if t not in pays_disponibles]
        if inconnus:
            print(f"Erreur : pays introuvables pour {annee} : {', '.join(inconnus)}")
            print("Liste disponible :")
            for p in pays_disponibles:
                print(f"- {p}")
            return

        # Appliquer filtre pays
        medailles_annee = [ligne for ligne in medailles_annee if ligne[0] in teams]

    # ----- Borne supérieure (avec doublons) -----
    resultat_sup = {}
    for team, _, _, medal in medailles_annee:
        if team not in resultat_sup:
            resultat_sup[team] = {'Gold_sup': 0, 'Silver_sup': 0, 'Bronze_sup': 0}
        if medal == 'Gold':
            resultat_sup[team]['Gold_sup'] += 1
        elif medal == 'Silver':
            resultat_sup[team]['Silver_sup'] += 1
        elif medal == 'Bronze':
            resultat_sup[team]['Bronze_sup'] += 1

    for t in resultat_sup:
        total = resultat_sup[t]['Gold_sup'] + resultat_sup[t]['Silver_sup'] + resultat_sup[t]['Bronze_sup']
        resultat_sup[t]['Total_sup'] = total

    # ----- Borne inférieure (sans doublons) -----
    unique_events = set()
    resultat_inf = {}
    for team, _, event, medal in medailles_annee:
        key = (team, event, medal)
        if key not in unique_events:
            unique_events.add(key)
            if team not in resultat_inf:
                resultat_inf[team] = {'Gold_inf': 0, 'Silver_inf': 0, 'Bronze_inf': 0}
            if medal == 'Gold':
                resultat_inf[team]['Gold_inf'] += 1
            elif medal == 'Silver':
                resultat_inf[team]['Silver_inf'] += 1
            elif medal == 'Bronze':
                resultat_inf[team]['Bronze_inf'] += 1

    for t in resultat_inf:
        total = resultat_inf[t]['Gold_inf'] + resultat_inf[t]['Silver_inf'] + resultat_inf[t]['Bronze_inf']
        resultat_inf[t]['Total_inf'] = total

    # Fusionner les deux résultats
    all_teams = set(resultat_sup.keys()).union(resultat_inf.keys())
    final = {}
    for team in all_teams:
        final[team] = {
            'Gold_inf': resultat_inf.get(team, {}).get('Gold_inf', 0),
            'Silver_inf': resultat_inf.get(team, {}).get('Silver_inf', 0),
            'Bronze_inf': resultat_inf.get(team, {}).get('Bronze_inf', 0),
            'Total_inf': resultat_inf.get(team, {}).get('Total_inf', 0),
            'Gold_sup': resultat_sup.get(team, {}).get('Gold_sup', 0),
            'Silver_sup': resultat_sup.get(team, {}).get('Silver_sup', 0),
            'Bronze_sup': resultat_sup.get(team, {}).get('Bronze_sup', 0),
            'Total_sup': resultat_sup.get(team, {}).get('Total_sup', 0)
        }

    # Tri par total supérieur décroissant
    final_trie = sorted(final.items(), key=lambda x: x[1]['Total_sup'], reverse=True)

    # Affichage
    print("Top 5 pays :")
    for team, stats in final_trie[:5]:
        print(f"{team} : {stats}")

    # Nom du fichier de sortie
    if teams == 'all':
        suffixe = 'all_countries'
    else:
        suffixe = '_'.join([t.replace(" ", "_") for t in teams])
    nom_fichier = f'resultats_medailles_{annee}_{suffixe}.csv'

    # Écriture dans un fichier CSV
    with open(nom_fichier, 'w', newline='', encoding='utf-8') as f_out:
        writer = csv.writer(f_out)
        # En-têtes
        writer.writerow([
            'Team',
            'Gold_inf', 'Silver_inf', 'Bronze_inf', 'Total_inf',
            'Gold_sup', 'Silver_sup', 'Bronze_sup', 'Total_sup'
        ])
        for team, stats in final_trie:
            writer.writerow([
                team,
                stats['Gold_inf'], stats['Silver_inf'], stats['Bronze_inf'], stats['Total_inf'],
                stats['Gold_sup'], stats['Silver_sup'], stats['Bronze_sup'], stats['Total_sup']
            ])
    print(f"Résultats enregistrés dans : {nom_fichier}")
    return final_trie

# Exemple d'appel
compter_medailles_par_pays(2016)
