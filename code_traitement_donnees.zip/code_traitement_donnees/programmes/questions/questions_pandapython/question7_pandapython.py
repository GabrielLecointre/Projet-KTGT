# Ce programme Python trie les sports selon le sexe par ordre croissant du poids et
# de la taille des participants aux Jeux Olympiques.
# ATTENTION : CHANGER LE CHEMIN DU FICHIER SI BESOIN

import pandas
import os
pandas.set_option('display.max_rows', 120)

# Lire le fichier .csv avec la base de données (CHEMIN DU FICHIER)
BDJO = pandas.read_csv(os.path.join("donnees", "athlete_events.csv"))

# Comment la taille des sportifs varient-ils selon les sports et le sexe ?

BDJOtaille = BDJO.dropna(subset=["Height"])
BDJOtaille.drop(columns=[
    "Name", "Age", "Weight", "Team", "NOC", "Games", "Season", "City", "Event", "Medal"
    ], inplace=True)
# Il ne reste plus que les cinq colonnes ID, Sex, Height, Year, Sport.
BDJOtaille.drop_duplicates(keep='first', inplace=True)
# On ne garde qu’une seule donnée par sportif pour un sport et une année donnés.
BDJOtaille.drop(columns=["ID", "Year"], inplace=True)
# Suppression de deux dernières colonnes inutiles une fois que
# l’on a conservé toutes les données et que les données souhaitées.
tailleGB = BDJOtaille.groupby(by=["Sport", "Sex"]).mean("Height")
tritaille = tailleGB.sort_values(by="Height", ascending=True)
print(tritaille)

# Comment le poids des sportifs varient-ils selon les sports et le sexe ?

BDJOpoids = BDJO.dropna(subset=["Weight"])
BDJOpoids.drop(columns=[
    "Name", "Age", "Height", "Team", "NOC", "Games", "Season", "City", "Event", "Medal"
    ], inplace=True)
# Il ne reste plus que les cinq colonnes ID, Sex, Weight, Year, Sport.
BDJOpoids.drop_duplicates(keep='first', inplace=True)
# On ne garde qu’une seule donnée par sportif pour un sport et une année donnés.
BDJOpoids.drop(columns=["ID", "Year"], inplace=True)
# Suppression de deux dernières colonnes inutiles une fois que
# l’on a conservé toutes les données et que les données souhaitées.
poidsGB = BDJOpoids.groupby(by=["Sport", "Sex"]).mean("Weight")
tripoids = poidsGB.sort_values(by="Weight", ascending=True)
print(tripoids)

chemin_fichier_tritaille = os.path.join('output/question_7', "tritaille.csv")
chemin_fichier_tripoids = os.path.join('output/question_7', "tripoids.csv")

# Enregistrement
tritaille.to_csv(chemin_fichier_tritaille, index=True)
tripoids.to_csv(chemin_fichier_tripoids, index=True)
