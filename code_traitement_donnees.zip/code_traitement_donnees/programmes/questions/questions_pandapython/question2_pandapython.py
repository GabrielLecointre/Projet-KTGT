import pandas as pd
import os


def compter_medailles_par_pays(year, team='all'):
    """
    Analyser les données des médailles obtenues lors des Jeux Olympiques pour
    une année donnée et enregistrer les résultats dans un fichier CSV.

    Cette fonction charge les données des athlètes
    (en supposant un fichier CSV avec des informations
    sur les événements, les équipes et les médailles),
    filtre les données pour une année spécifique,
    et calcule deux types de totaux de médailles :
    - Total supérieur (en comptabilisant les doublons de médailles
    pour une équipe donnée).
    - Total inférieur (en comptabilisant chaque médaille une seule fois
    par équipe et événement).
    Les résultats sont ensuite triés par le nombre total de médailles (supérieur),
    et enregistrés dans un fichier CSV.

    Parameters:
    -----------
    year : int
        L'année pour laquelle les résultats doivent être analysés
        (ex. 2008, 2016).

    team : str ou list, optionnel, par défaut 'all'
        Le ou les pays à inclure dans l'analyse. Si 'all', tous les pays
        seront inclus.
        Si une chaîne de caractères, seule l'équipe spécifiée sera incluse.
        Si une liste de chaînes de caractères, seules les équipes présentes
        dans cette liste seront prises en compte. Les équipes doivent être des
        noms exacts tels qu'ils apparaissent dans les données.

    Return:
    --------
    pd.DataFrame
        Un DataFrame contenant les résultats des médailles par équipe et type de médaille, avec
        les totaux supérieurs et inférieurs pour chaque équipe. Ce DataFrame est également
        enregistré dans un fichier CSV.

    Example:
    --------
    analyser_et_enregistrer_medailles(2016)
    analyser_et_enregistrer_medailles(2016, team='France')
    analyser_et_enregistrer_medailles(2016, team=['USA', 'China'])

    Notes:
    ------
    Le fichier CSV généré aura le nom suivant :
    - 'resultats_medailles_<year>_<team>.csv', où `<year>` est l'année et
    `<team>` est soit 'all_countries' (si 'all' est passé), soit un nom de
    pays (ou plusieurs séparés par des underscores).

    Exemples de colonnes dans le fichier CSV :
    - Gold_inf : Nombre de médailles d'or sans doublons.
    - Silver_inf : Nombre de médailles d'argent sans doublons.
    - Bronze_inf : Nombre de médailles de bronze sans doublons.
    - Gold_sup : Nombre de médailles d'or avec doublons.
    - Silver_sup : Nombre de médailles d'argent avec doublons.
    - Bronze_sup : Nombre de médailles de bronze avec doublons.
    - Total_inf : Total des médailles sans doublons.
    - Total_sup : Total des médailles avec doublons.

    Si un ou plusieurs pays spécifiés ne sont pas trouvés pour l'année donnée,
    un message d'erreur sera affiché et l'exécution sera arrêtée.
    """
    # Charger les données
    df = pd.read_csv('donnees/athlete_events.csv')

    # Ne conserver que les colonnes utiles
    donnees = df[['Team', 'Year', 'Event', 'Medal']]

    # Filtrer par année
    donnees_annee = donnees[donnees['Year'] == year]

    # Liste des pays disponibles cette année-là
    pays_disponibles = sorted(donnees_annee['Team'].dropna().unique())

    # Gérer le filtre sur les pays
    if team != 'all':
        if isinstance(team, str):
            team = [team]

        # Vérifier que tous les pays donnés existent dans les données
        pays_inconnus = [p for p in team if p not in pays_disponibles]

        if pays_inconnus:
            print(f"Erreur : le(s) pays suivant(s) sont introuvables pour l'année {year} : {', '.join(pays_inconnus)}")
            print("Veuillez choisir parmi la liste suivante :")
            for pays in pays_disponibles:
                print(f"- {pays}")
            return  # Arrêter l'exécution de la fonction

        # Appliquer le filtre
        donnees_annee = donnees_annee[donnees_annee['Team'].isin(team)]

    # --------- Borne supérieure (avec doublons) ---------
    medailles_sup = donnees_annee.groupby(['Team', 'Medal']).size().unstack(fill_value=0)
    medailles_sup['Total_sup'] = medailles_sup.sum(axis=1)

    # --------- Borne inférieure (sans doublons) ---------
    donnees_sans_doublons = donnees_annee.drop_duplicates(subset=['Team', 'Event', 'Medal'])
    medailles_inf = donnees_sans_doublons.groupby(['Team', 'Medal']).size().unstack(fill_value=0)
    medailles_inf['Total_inf'] = medailles_inf.sum(axis=1)

    # Renommer les colonnes
    medailles_inf = medailles_inf.rename(columns={
        'Gold': 'Gold_inf',
        'Silver': 'Silver_inf',
        'Bronze': 'Bronze_inf'
    })
    medailles_sup = medailles_sup.rename(columns={
        'Gold': 'Gold_sup',
        'Silver': 'Silver_sup',
        'Bronze': 'Bronze_sup'
    })

    # Fusion
    resultat = pd.merge(medailles_inf, medailles_sup, left_index=True, right_index=True, how='outer')
    resultat = resultat.fillna(0).astype(int)

    # Trier
    resultat = resultat.sort_values(by='Total_sup', ascending=False)

    # Affichage
    print(resultat.head(5))

    # Génération du nom de fichier
    if team == 'all':
        suffixe = 'all_countries'
    else:
        suffixe = '_'.join([t.replace(" ", "_") for t in team])

    nom_fichier = f"resultats_medailles_{year}_{suffixe}.csv"
    chemin_fichier = os.path.join('output', nom_fichier)

    # Enregistrement
    resultat.to_csv(chemin_fichier, index=True)
    print(f"Résultats enregistrés dans : {nom_fichier}")

    return resultat
