"""
Question 2 (obligatoire)
Trouvez des bornes inférieures et supérieures pour le nombre de médailles par nation
pour les Jeux Olympiques de 2016.
"""

import pandas as pd
import os


def compter_medailles_par_pays(year, team="all"):
    """
    Analyser les données des médailles obtenues lors des Jeux Olympiques pour
    une année donnée et enregistrer les résultats dans un fichier CSV.

    Cette fonction charge les données des athlètes (en supposant un fichier CSV
    avec des informations sur les événements, les pays et les médailles),
    filtre les données pour une année spécifique, et calcule deux types de totaux
    de médailles :
    - Total supérieur (en comptabilisant les doublons de médailles pour un pays donnée).
    - Total inférieur (en comptabilisant chaque médaille une seule fois par pays et
    événement).

    Les résultats sont ensuite triés par le nombre total de médailles (supérieur),
    et enregistrés dans un fichier CSV.

    Parameters:
    -----------
    year : int
        L'année pour laquelle les résultats doivent être analysés (ex. 2008, 2016).

    team : str ou list, optionnel, par défaut 'all'
        Le ou les pays à inclure dans l'analyse. Si 'all', tous les pays seront inclus.
        Si une chaîne de caractères, seule l'équipe spécifiée sera incluse.
        Si une liste de chaînes de caractères, seules les équipes présentes dans cette
        liste seront prises en compte.

    Return:
    --------
    pd.DataFrame
        Un DataFrame contenant les résultats des médailles par pays et type de médaille,
        avec les totaux supérieurs et inférieurs pour chaque pays.
        Ce DataFrame est également enregistré dans un fichier CSV.

    Notes:
    ------
    Le fichier CSV généré aura un nom du type :
    - 'resultats_medailles_<year>_<team>.csv'

    Exemples de colonnes dans le fichier CSV :
    - Gold_inf, Silver_inf, Bronze_inf, Total_inf : sans doublons
    - Gold_sup, Silver_sup, Bronze_sup, Total_sup : avec doublons

    Si un ou plusieurs pays spécifiés ne sont pas trouvés pour l'année donnée,
    un message d'erreur sera affiché et l'exécution sera arrêtée.
    """
    # Charger le fichier CSV contenant les données des athlètes olympiques
    df = pd.read_csv("donnees/athlete_events.csv")

    # Conserver uniquement les colonnes nécessaires à l'analyse
    donnees = df[["Team", "Year", "Event", "Medal"]]

    # Filtrer les données pour l'année spécifiée
    donnees_annee = donnees[donnees["Year"] == year]

    # Identifier la liste des pays disponibles cette année-là
    pays_disponibles = sorted(donnees_annee["Team"].dropna().unique())

    # Si on souhaite filtrer sur un ou plusieurs pays spécifiques
    if team != "all":
        # Convertir en liste si une seule équipe est donnée
        if isinstance(team, str):
            team = [team]

        # Vérifier que tous les pays demandés existent dans les données
        pays_inconnus = [p for p in team if p not in pays_disponibles]

        if pays_inconnus:
            # Afficher une erreur claire si des pays sont manquants
            print(
                "Erreur : le(s) pay(s) suivant(s) sont introuvables pour"
                f"l'année {year} : {', '.join(pays_inconnus)}"
            )

            print("Veuillez choisir parmi la liste suivante :")
            for pays in pays_disponibles:
                print(f"- {pays}")
            return  # Arrêter la fonction si erreur

        # Appliquer le filtre sur les équipes sélectionnées
        donnees_annee = donnees_annee[donnees_annee["Team"].isin(team)]

    # --------- Calcul des médailles avec doublons (borne supérieure) ---------
    # Regrouper par pays et type de médaille, compter chaque occurrence
    medailles_sup = (
        donnees_annee.groupby(["Team", "Medal"]).size().unstack(fill_value=0)
    )
    # Ajouter une colonne pour le total supérieur
    medailles_sup["Total_sup"] = medailles_sup.sum(axis=1)

    # --------- Calcul des médailles sans doublons (borne inférieure) ---------
    # Supprimer les doublons d'une même équipe ayant gagné plusieurs fois dans le même
    # événement
    donnees_sans_doublons = donnees_annee.drop_duplicates(
        subset=["Team", "Event", "Medal"]
    )
    # Regrouper et compter les médailles distinctes
    medailles_inf = (
        donnees_sans_doublons.groupby(["Team", "Medal"]).size().unstack(fill_value=0)
    )
    # Ajouter une colonne pour le total inférieur
    medailles_inf["Total_inf"] = medailles_inf.sum(axis=1)

    # Renommer les colonnes pour clarifier les bornes inférieure/supérieure
    medailles_inf = medailles_inf.rename(
        columns={"Gold": "Gold_inf", "Silver": "Silver_inf", "Bronze": "Bronze_inf"}
    )
    medailles_sup = medailles_sup.rename(
        columns={"Gold": "Gold_sup", "Silver": "Silver_sup", "Bronze": "Bronze_sup"}
    )

    # Fusionner les deux jeux de données (borne inférieure et supérieure)
    resultat = pd.merge(
        medailles_inf, medailles_sup, left_index=True, right_index=True, how="outer"
    )

    # Remplacer les éventuelles valeurs manquantes par zéro et convertir en entier
    resultat = resultat.fillna(0).astype(int)

    # Trier les résultats par le total de médailles avec doublons décroissant
    resultat = resultat.sort_values(by="Total_sup", ascending=False)

    # Afficher les 5 premiers pays pour contrôle
    print(resultat.head(5))

    # Générer un nom de fichier lisible selon le pays ou les pays
    if team == "all":
        suffixe = "all_countries"
    else:
        # Remplacer les espaces par des underscores dans les noms de pays
        suffixe = "_".join([t.replace(" ", "_") for t in team])

    nom_fichier = f"resultats_medailles_{year}_{suffixe}.csv"
    chemin_fichier = os.path.join("output/question_2", nom_fichier)

    # Enregistrer les résultats dans un fichier CSV
    resultat.to_csv(chemin_fichier, index=True)
    print(f"Résultats enregistrés dans : {nom_fichier}")

    # Réinitialiser l'index pour retour lisible
    resultat = resultat.reset_index()

    return resultat


compter_medailles_par_pays(2016)
