# Ce programme Python donne le nombre de sportifs par édition et par sports.
# Il affiche ensuite trois graphiques avec les 24 sports qui ont compté
# le plus de participants : un premier graphique avec les 8 premiers sports,
# un deuxième avec les 8 sports suivants (du 9e sport au 16e)
# et un dernier avec encore les 8 suivants (donc du 17e sport au 24e).
# ATTENTION : CHANGER LE CHEMIN DU FICHIER SI BESOIN

import pandas
import os
import matplotlib.pyplot as plt

pandas.set_option("display.max_rows", 910)

# Lire le fichier .csv avec la base de données
BDJO = pandas.read_csv(os.path.join("donnees", "athlete_events.csv"))

# Comment évolue le nombre de sportifs par sport au fil des différentes éditions ?

BDJOevo = BDJO
BDJOevo.drop(
    columns=[
        "Sex",
        "Height",
        "Name",
        "Age",
        "Weight",
        "Team",
        "NOC",
        "Games",
        "Season",
        "City",
        "Event",
        "Medal",
    ],
    inplace=True,
)
# Il ne reste plus que les trois colonnes ID, Year, Sport.
BDJOevo.drop_duplicates(keep="first", inplace=True)
# On ne garde qu’une seule donnée par sportif pour un sport et une année donnés.
BDJOevo.drop(
    columns=["ID"],
    inplace=True,
)
# Je supprime la colonne ID une fois que je n’ai gardé le même sportif qu’une fois par
# sport et par édition des Jeux Olympiques.
nbSportifsparSportetAnnee = BDJOevo.groupby(["Sport", "Year"]).size()
# Je compte le nombre de ligne (et donc de sportifs) par sport et par édition.
trinbSportifs = nbSportifsparSportetAnnee.sort_values(ascending=True)
# Je les classe par ordre croissant avant d’afficher le résultat.
print(trinbSportifs)

# Enregistrement
chemin_fichier_trinbSportifs = os.path.join('output/question_8', "trinbSportifs.csv")
trinbSportifs.to_csv(chemin_fichier_trinbSportifs, index=True)

nbSportifsparSportetAnnee = nbSportifsparSportetAnnee.reset_index(name="Nbre_Sportifs")

plt.figure(figsize=(14, 8))

# Je crée une ligne pour les huit sports qui cumulent
# le plus de participants de 1896 à 2016.
sports_to_plot = (
    nbSportifsparSportetAnnee.groupby("Sport")["Nbre_Sportifs"]
    .sum()
    .sort_values(ascending=False)
    .head(8)
    .index
)
for sport in sports_to_plot:
    sport_data = nbSportifsparSportetAnnee[nbSportifsparSportetAnnee["Sport"] == sport]
    plt.scatter(sport_data["Year"], sport_data["Nbre_Sportifs"], label=sport, alpha=0.6)

# Je personnalise le graphique...
plt.title("Évolution du nombre de sportifs par sport pour les huit premiers sports")
plt.xlabel("Année")
plt.ylabel("Nombre de sportifs")
plt.legend(title="Sport", bbox_to_anchor=(1.05, 1), loc="upper left")
plt.grid(True)
plt.tight_layout()

# sauvegarde du graphique
graph_path = os.path.join("output/question_8", 'evol_nbsportifs_8_premiers_sports.png')
plt.savefig(graph_path)

# ...avant de l’afficher.
if __name__ == "__main__":
    plt.show()

# Je crée une ligne pour les huit sports suivants (du 9e au 16e sport) qui cumulent
# le plus de participants de 1896 à 2016.
sports_to_plot2 = (
    nbSportifsparSportetAnnee.groupby("Sport")["Nbre_Sportifs"]
    .sum()
    .sort_values(ascending=False)
    .iloc[8:16]
    .index
)
for sport in sports_to_plot2:
    sport_data = nbSportifsparSportetAnnee[nbSportifsparSportetAnnee["Sport"] == sport]
    plt.scatter(sport_data["Year"], sport_data["Nbre_Sportifs"], label=sport, alpha=0.6)

# Je personnalise le graphique...
plt.title("Évolution du nombre de sportifs par sport pour les 9e au 16e sports")
plt.xlabel("Année")
plt.ylabel("Nombre de sportifs")
plt.legend(title="Sport", bbox_to_anchor=(1.05, 1), loc="upper left")
plt.grid(True)
plt.tight_layout()

# sauvegarde du graphique
graph_path = os.path.join("output/question_8", 'evol_nbsportifs_9_16_eme_sport.png')
plt.savefig(graph_path)

# ...avant de l’afficher.
if __name__ == "__main__":
    plt.show()

# Je crée une ligne pour les huit sports suivants (du 17e au 24e sport) qui cumulent
# le plus de participants de 1896 à 2016.
sports_to_plot3 = (
    nbSportifsparSportetAnnee.groupby("Sport")["Nbre_Sportifs"]
    .sum()
    .sort_values(ascending=False)
    .iloc[16:24]
    .index
)
for sport in sports_to_plot3:
    sport_data = nbSportifsparSportetAnnee[nbSportifsparSportetAnnee["Sport"] == sport]
    plt.scatter(sport_data["Year"], sport_data["Nbre_Sportifs"], label=sport, alpha=0.6)

# Je personnalise le graphique...
plt.title("Évolution du nombre de sportifs par sport pour les 17e au 24e sports")
plt.xlabel("Année")
plt.ylabel("Nombre de sportifs")
plt.legend(title="Sport", bbox_to_anchor=(1.05, 1), loc="upper left")
plt.grid(True)
plt.tight_layout()

# sauvegarde du graphique
graph_path = os.path.join("output/question_8", 'evol_nbsportifs_17_24_eme_sport.png')
plt.savefig(graph_path)

# ...avant de l’afficher.
if __name__ == "__main__":
    plt.show()
