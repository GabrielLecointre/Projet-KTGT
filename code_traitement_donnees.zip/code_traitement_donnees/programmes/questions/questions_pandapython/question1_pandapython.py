'''
Question 1 (obligatoire)
Déterminez le nombre de médailles gagnées par Michael Phelps. Son nom complet
est Michael Fred Phelps, II.
'''
import pandas as pd
import os


def nb_medailles_athlete(nom, annee=None):
    """
    Calcule le nombre de médailles remportées par un athlète dont le nom
    contient une chaîne donnée, avec la possibilité de filtrer les résultats
    par année. La fonction génère un fichier Excel avec deux
    onglets : un pour les détails des événements où l'athlète a participé, et
    un autre pour un résumé des médailles obtenues. Elle affiche également des
    informations sur le nombre de médailles ainsi que la liste des noms
    athlètes dans la console.

    Parameters
    ----------
    nom : str
        Une chaîne de caractères représentant une partie du nom de l'athlète.
        La recherche est insensible à la casse et permet de trouver tous les
        athlètes dont le nom contient cette chaîne.

    annee : int, optional
        Une année spécifique pour laquelle filtrer les résultats (ex, 2008).
        Si aucune année n’est fournie (valeur par défaut : None), les données
        de toutes les années sont prises en compte.

    Return
    ------
    dict
        Un dictionnaire contenant :
        - 'total_medailles' : int, le nombre total de médailles
        - 'resume' : DataFrame, tableau résumé des médailles par type
        - 'athletes_found' : DataFrame, noms des athlètes trouvés

    Notes
    -----
    La fonction génère un fichier Excel avec deux onglets :
    - **Details** : Contient les détails des événements
    (année, nom, événement, médaille) auxquels l'athlète a participé.
    - **Résumé** : Présente un résumé des médailles obtenues dans chaque
    catégorie (or, argent, bronze) ainsi que le total.
    """

    # Charger le fichier CSV contenant les données des athlètes
    df = pd.read_csv('donnees/athlete_events.csv')

    # Ne garder que les colonnes nécessaires à l'analyse
    donnees = df[['Year', 'Name', 'Event', 'Medal']]

    # Filtrer les lignes contenant le nom de l'athlète (insensible à la casse)
    donnees_nom = donnees[donnees['Name'].str.lower().str.contains(nom.lower())]

    # Si une année est spécifiée, filtrer également par année
    if annee is not None:
        donnees_nom = donnees_nom[donnees_nom['Year'] == annee]

    # Supprimer les doublons pour éviter de compter plusieurs fois le même événement
    donnees_nom = donnees_nom.drop_duplicates()

    # Compter le nombre de médailles par type (Gold, Silver, Bronze)
    medailles_count = donnees_nom['Medal'].value_counts()

    # Calculer le total des médailles
    total_medailles = medailles_count.sum()

    # Créer un DataFrame de résumé à partir des comptages
    resume_df = pd.DataFrame(medailles_count)
    resume_df.columns = ['Nombre']  # Renommer la colonne
    resume_df.loc['Total des médailles'] = total_medailles  # Ajouter total

    # Générer un nom de fichier basé sur le nom de l'athlète et l'année
    nom_fichier_base = nom.strip().lower().replace(' ', '_')  # Nettoyage du nom
    suffixe_annee = f"_{annee}" if annee else "_toutes_annees"
    nom_fichier = f"nb_medaille_{nom_fichier_base}{suffixe_annee}.xlsx"
    chemin_fichier = os.path.join('output/question_1/', nom_fichier)

    # Sauvegarder les résultats dans un fichier Excel avec deux onglets
    with pd.ExcelWriter(chemin_fichier) as writer:
        donnees_nom.to_excel(writer, sheet_name='Details', index=False)
        resume_df.to_excel(writer, sheet_name='Résumé')

    # Afficher un résumé dans la console
    print(f"\nLe nombre de médailles des athlètes dont le nom contient '{nom}'"
          f"{' en ' + str(annee) if annee else ''} est : {total_medailles}")

    # Extraire et afficher les noms uniques des athlètes trouvés
    noms_uniques = donnees_nom['Name'].dropna().unique()
    print("\nNoms des athlètes trouvés :")
    for n in noms_uniques:
        print(f"- {n}")

    # Créer un DataFrame pour afficher les noms des athlètes
    noms_df = pd.DataFrame(noms_uniques, columns=['Athlètes trouvés'])
    print("\nAthlètes trouvés :")
    print(noms_df)

    # Retourner les résultats sous forme de dictionnaire
    resultats = {
        'total_medailles': total_medailles,
        'resume': resume_df,
        'athletes_found': noms_df
    }

    return resultats
