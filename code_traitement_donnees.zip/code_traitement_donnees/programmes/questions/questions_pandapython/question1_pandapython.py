import pandas as pd
import os


def nb_medailles_athlete(nom, annee=None):
    """
    Calcule le nombre de médailles remportées par un athlète dont le nom
    contient une chaîne donnée, avec la possibilité de filtrer les résultats
    par année. La fonction génère un fichier Excel avec deux
    onglets : un pour les détails des événements où l'athlète a participé, et
    un autre pour un résumé des médailles obtenues. Elle affiche également des
    informations sur le nombre de médailles ainsi que la liste des noms
    athlètes dans la console.

    Parameters
    ----------
    nom : str
        Une chaîne de caractères représentant une partie du nom de l'athlète.
        La recherche est insensible à la casse et permet de trouver tous les
        athlètes dont le nom contient cette chaîne.

    annee : int, optional
        Une année spécifique pour laquelle filtrer les résultats (ex, 2008).
        Si aucune année n’est fournie (valeur par défaut : None), les données
        de toutes les années sont prises en compte.

    Returns
    -------
    None
        La fonction n'a pas de valeur de retour. Elle effectue des actions sur
        les données et écrit un fichier Excel avec deux onglets. Elle affiche
        également les résultats dans la console.

    Notes
    -----
    La fonction génère un fichier Excel avec deux onglets :
    - **Details** : Cet onglet contient les détails des événements
    (année, nom, événement, médaille) auxquels l'athlète a participé.
    - **Résumé** : Cet onglet présente un résumé des médailles de l'athlète,
    avec le nombre de médailles obtenues dans chaque catégorie
    (or, argent, bronze), ainsi que le total des médailles.

    Affichage dans la console
    -------------------------
    La fonction affiche dans la console :
    - Un **résumé des médailles**, sous forme d'un tableau indiquant le nombre
    de médailles dans chaque catégorie (or, argent, bronze) ainsi que le total
    des médailles.
    - Le **nombre total de médailles** des athlètes dont le nom contient la
    chaîne `nom` recherchée.
    - La liste des **noms des athlètes** trouvés dans les données, qui
    contiennent la chaîne `nom` fournie.

    Exemple
    -------
    >>> nb_medailles_athlete("Michael Bruce")
    Le nombre de médailles des athlètes dont le nom contient 'Michael Bruce' est : 0

    Noms des athlètes trouvés :
    - Michael Bruce Frayne
    - Michael Bruce McKenzie
    - Michael Bruce Swinton Tulloh

    >>> nb_medailles_athlete("Michael Fred Phelps, II")
    Le nombre de médailles des athlètes dont le nom contient 'Michael Fred Phelps, II' est : 28

    Noms des athlètes trouvés :
    - Michael Fred Phelps, II

    >>> nb_medailles_athlete("Michael Fred Phelps, II", 2008)
    Le nombre de médailles des athlètes dont le nom contient 'Michael Fred Phelps, II' en 2008 est : 8

    Noms des athlètes trouvés :
    - Michael Fred Phelps, II
    """

    # Charger les données avec pandas
    df = pd.read_csv('donnees/athlete_events.csv')

    # Ne conserver que les colonnes d'intérêt
    donnees = df[['Year', 'Name', 'Event', 'Medal']]

    # Filtrer par nom insensible à la casse
    donnees_nom = donnees[donnees['Name'].str.lower().str.contains(nom.lower())]

    # Filtrer par année si spécifiée
    if annee is not None:
        donnees_nom = donnees_nom[donnees_nom['Year'] == annee]

    # Supprimer des doublons
    donnees_nom = donnees_nom.drop_duplicates()

    # Compter les modalités de médailles
    medailles_count = donnees_nom['Medal'].value_counts()
    total_medailles = medailles_count.sum()

    # Créer un DataFrame de résumé
    resume_df = pd.DataFrame(medailles_count)
    resume_df.columns = ['Nombre']
    resume_df.loc['Total des médailles'] = total_medailles

    # Nettoyer le nom pour le fichier
    nom_fichier_base = nom.strip().lower().replace(' ', '_')
    suffixe_annee = f"_{annee}" if annee else "_toutes_annees"
    nom_fichier = f"nb_medaille_{nom_fichier_base}{suffixe_annee}.xlsx"
    chemin_fichier = os.path.join('output/question_1/', nom_fichier)

    # Écrire dans un fichier Excel avec deux onglets
    with pd.ExcelWriter(chemin_fichier) as writer:
        donnees_nom.to_excel(writer, sheet_name='Details', index=False)
        resume_df.to_excel(writer, sheet_name='Résumé')

    # Afficher les résultats dans la console
    print(f"\nLe nombre de médailles des athlètes dont le nom contient '{nom}'"
          f"{' en ' + str(annee) if annee else ''} est : {total_medailles}")

    noms_uniques = donnees_nom['Name'].dropna().unique()
    print("\nNoms des athlètes trouvés :")
    for n in noms_uniques:
        print(f"- {n}")

    # Afficher les noms uniques dans un DataFrame
    noms_uniques = donnees_nom['Name'].dropna().unique()
    noms_df = pd.DataFrame(noms_uniques, columns=['Athlètes trouvés'])

    print("\nAthlètes trouvés :")
    print(noms_df)

    # Créer un dictionnaire de résultats
    resultats = {
        'total_medailles': total_medailles,
        'resume': resume_df,
        'athletes_found': noms_df
    }

    return resultats
