"""'
Ce programme permet de classer les épreuves olympiques en groupes (clusters) sur la
base de plusieurs caractéristiques (comme le nombre de participants, la proportion
de femmes, l'âge, etc.) et de visualiser ces clusters de manière interprétable et
graphique.
Il offre une analyse des tendances et des différences entre les épreuves sportives
à travers différentes périodes historiques.
Ce programme est une analyse des épreuves sportives des Jeux Olympiques, en se
concentrant sur la classification et la réduction des dimensions des données des
athlètes et des épreuves. Voici un résumé de ce qu'il permet de faire :

1. Chargement des données

    Le programme commence par charger un fichier CSV (athlete_events.csv) qui contient
    des informations sur les athlètes et les événements des Jeux Olympiques.

2. Traitement des données

    Correction des types d’épreuves : Le programme distingue les épreuves individuelles
    des épreuves collectives. Une épreuve est considérée comme "collective" si elle
    attribue 6 médailles ou plus (ce seuil est modifiable). Les épreuves collectives
    sont ensuite étiquetées comme telles dans les données.

    Construction d’une table récapitulative des épreuves : Pour chaque épreuve
    (ou événement), des statistiques sont calculées, telles que le nombre de
    participants, la proportion de femmes, l’âge moyen des athlètes, etc. Cette table
    sert de base pour l’analyse ultérieure.

3. Classification des épreuves par période

    Les données sont divisées en 4 périodes de 25 ans :

        1916-1940
        1941-1965
        1966-1990
        1991-2016

    Pour chaque période, les variables de la table sont normalisées
    (standardisation des valeurs) et une classification K-means est appliquée. K-means
    est un algorithme de clustering non supervisé qui groupe les épreuves en fonction
    de leurs caractéristiques. Trois groupes (ou clusters) sont générés pour
    chaque période.

4. Réduction de dimensions avec PCA (Analyse en Composantes Principales)

    Le programme applique une réduction de dimensions PCA pour réduire les
    caractéristiques (comme l'âge, le poids, etc.) à deux dimensions principales
    afin de faciliter la visualisation et l'interprétation des clusters.

    Ensuite, un graphique de visualisation PCA est généré où chaque point représente
    une épreuve et est coloré en fonction du cluster auquel il appartient.
    Ce graphique est divisé en sous-graphes par période.

5. Interprétation des clusters

    Le programme fournit une interprétation des clusters en analysant les
    caractéristiques des épreuves dans chaque cluster, telles que :

        Le nombre de participants (individuel ou collectif)
        La proportion de femmes
        Le poids et la taille moyens des athlètes

    Ces interprétations sont écrites et enregistrées dans un fichier texte.

6. Statistiques par cluster

    Les moyennes et écarts-types de plusieurs caractéristiques (poids, taille, âge,
    etc.) sont calculés pour chaque cluster, tant pour l’ensemble des périodes que pour
    chaque période.

    Ces statistiques sont ensuite exportées vers un fichier Excel pour permettre une
    analyse plus détaillée.

7. Visualisations finales

    Graphique PCA : Une visualisation des épreuves en fonction de leurs clusters,
    avec réduction de dimensions.

    Image interprétative des clusters : Un texte interprétant les différents clusters
    est généré dans une image pour être plus facilement partagé.

    Résumé statistique par période : Un tableau récapitulant les statistiques de chaque
    cluster par période est converti en une image et sauvegardé.

8. Exportation des résultats

    Les résultats de l'analyse, y compris les statistiques et les visualisations, sont
    exportés vers plusieurs fichiers :

        Excel : Contenant les moyennes et écarts-types pour chaque cluster et période.
        Fichiers texte : Interprétations détaillées de chaque cluster.
        Images : Graphiques et tableaux interprétatifs sauvegardés sous forme d'images.
"""

import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
import seaborn as sns
import matplotlib.pyplot as plt
import os
import textwrap
from PIL import Image
import io


# -----------------------------
# Chargement des données
# -----------------------------
df = pd.read_csv("donnees/athlete_events.csv")

# -----------------------------
# Étapes auxiliaires
# -----------------------------


# Correction des données pour distinguer les épreuves individuelles et collectives,
# onn suppose qu’une épreuve est collective si elle attribue ≥ 6 médailles
def ajouter_type_epreuve(donnees):
    corrected_rows = []
    for event, group in donnees.groupby("Event"):
        medal_counts = group["Medal"].value_counts()
        total_medals = medal_counts.sum()

        if total_medals >= 6:
            kept_medals = []
            for medal in ["Gold", "Silver", "Bronze"]:
                if medal in group["Medal"].values:
                    first_occurrence = group[group["Medal"] == medal].iloc[[0]]
                    kept_medals.append(first_occurrence)
            if kept_medals:
                corrected_rows.append(pd.concat(kept_medals))
        else:
            corrected_rows.append(group)

    donnees_corr = pd.concat(corrected_rows, ignore_index=True)
    donnees_corr["Type"] = "individuel"
    epreuves_collectives = donnees_corr["Event"].value_counts()
    epreuves_collectives = epreuves_collectives[epreuves_collectives >= 6].index
    donnees_corr.loc[donnees_corr["Event"].isin(epreuves_collectives), "Type"] = (
        "collectif"
    )
    return donnees_corr


# Chaque ligne représente une épreuve. Pour chaque épreuve, on calcule des variables
# statistiques qui vont servir de caractéristiques pour la classification
def construire_table_epreuves(donnees):
    table = donnees.groupby("Event").agg(
        {
            "Sport": "first",
            "ID": "nunique",
            "NOC": "nunique",
            "Sex": lambda x: (x == "F").sum() / len(x),
            "Age": ["mean", "std"],
            "Weight": ["mean", "std"],
            "Height": ["mean", "std"],
            "Year": "min",
            "Type": "first",
        }
    )

    table.columns = [
        "Sport",
        "Nb participants",
        "Nb pays",
        "Part femmes",
        "Âge moyen",
        "Écart âge",
        "Poids moyen",
        "Écart poids",
        "Taille moyenne",
        "Écart taille",
        "Année apparition",
        "Type",
    ]
    table = table.reset_index()
    table["Nb épreuves dans le sport"] = table.groupby("Sport")["Event"].transform(
        "count"
    )
    table["Type collectif"] = (table["Type"] == "collectif").astype(int)
    return table


# -----------------------------
# Traitement par période
# -----------------------------
# les statistiques qui vont servir de caractéristiques (features) pour la classification
colonnes_features = [
    "Nb participants",
    "Part femmes",
    "Âge moyen",
    "Poids moyen",
    "Taille moyenne",
]


# écoupage en 4 périodes de 25 ans
periodes = {
    "1916-1940": (1916, 1940),
    "1941-1965": (1941, 1965),
    "1966-1990": (1966, 1990),
    "1991-2016": (1991, 2016),
}

# Classification K-means (non supervisée)

# Pour chaque période
tables_par_periode = []
# On normalise les variables
scaler = StandardScaler()

# On applique K-means avec 4 clusters (groupes)
for nom_periode, (debut, fin) in periodes.items():
    print(f"→ Traitement de la période {nom_periode}")
    subset = df[(df["Year"] >= debut) & (df["Year"] <= fin)].copy()
    subset = ajouter_type_epreuve(subset)
    table = construire_table_epreuves(subset)
    table["Période"] = nom_periode

    # Nettoyage
    table = table.dropna(subset=colonnes_features)
    X_scaled = scaler.fit_transform(table[colonnes_features])

    # KMeans
    kmeans = KMeans(n_clusters=3, random_state=0)
    table["Cluster"] = kmeans.fit_predict(X_scaled)

    tables_par_periode.append(table)

# -----------------------------
# PCA sur toutes les périodes
# -----------------------------
table_periodes = pd.concat(tables_par_periode, ignore_index=True)
X_scaled_all = scaler.fit_transform(table_periodes[colonnes_features])
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_scaled_all)

table_periodes["Dim1"] = X_pca[:, 0]
table_periodes["Dim2"] = X_pca[:, 1]

# -----------------------------
# Visualisation PCA
# -----------------------------

# Définir le style
sns.set(style="whitegrid")

# Créer le graphique
g = sns.relplot(
    data=table_periodes,
    x="Dim1",
    y="Dim2",
    hue="Cluster",
    col="Période",
    palette="tab10",
    kind="scatter",
    height=5,
    aspect=1,
)

# Ajouter un titre global
g.fig.suptitle(
    "Classification des épreuves sportives par période (PCA + K-means)",
    fontsize=14,
    fontweight="bold",
)

# Ajuster la mise en page
g.fig.tight_layout()  # Utilisez `g.fig.tight_layout()` au lieu de `plt.tight_layout()`

# Sauvegarder le fichier
g.fig.savefig("output/problematique/pca_clusters_par_periode.png")

if __name__ == "__main__":
    plt.show()
    plt.close()

# Affiche les contributions des variables aux deux premiers axes PCA
pca_components = pd.DataFrame(
    pca.components_,
    columns=colonnes_features,  # les noms des variables originales
    index=["Dim1", "Dim2"],
)

print("Contribution des variables aux axes  :")
print(pca_components.T.sort_values("Dim1", ascending=False))  # trier pour voir l'impact

# stat desc
# Fusionner les données avec leur cluster
data_clustered = table_periodes.copy()

# Moyenne de chaque variable par cluster
cluster_summary_period = (
    data_clustered.groupby(["Période", "Cluster"])[colonnes_features].mean().round(2)
)
print("Résumé statistique par cluster :")
print(cluster_summary_period)

# export excel
with pd.ExcelWriter("output/problematique/resume_clusters_period.xlsx") as writer:
    cluster_summary_period.to_excel(writer, sheet_name="Moyennes")
    cluster_summary_period.to_excel(writer, sheet_name="Ecart-type")

# Moyenne de chaque variable par cluster
cluster_summary = data_clustered.groupby("Cluster")[colonnes_features].mean().round(2)
print("Résumé statistique par cluster :")
print(cluster_summary)

# Écart-type
cluster_std = data_clustered.groupby("Cluster")[colonnes_features].std().round(2)

# export excel
with pd.ExcelWriter("output/problematique/resume_clusters.xlsx") as writer:
    cluster_summary.to_excel(writer, sheet_name="Moyennes")
    cluster_std.to_excel(writer, sheet_name="Ecart-type")


# profils moyens pas cluster
def interpreter_cluster(cluster_id, summary):
    ligne = summary.loc[cluster_id]
    texte = f"Cluster {cluster_id} :\n"

    # Une épreuve comprend au moins deux participants.
    # En dessous de 4 participants en moyenne par épreuve, on considère
    # qu'elles sont principalement individuelles.
    if ligne["Nb participants"] < 4:
        texte += "- Épreuves sportives en moyenne majoritairement individuelles\n"
    else:
        texte += "- Épreuves sportives en moyenne majoritairement collectives\n"

    # Répartition femmes / hommes
    if ligne["Part femmes"] > 0.6:
        texte += "- Avec des athlètes principalement féminins\n"
    elif ligne["Part femmes"] < 0.4:
        texte += "- Avec des athlètes principalement masculins\n"
    else:
        texte += "- Équilibre mixte entre femmes et hommes\n"

    # Analyse du poids moyen
    if ligne["Poids moyen"] >= 77:
        texte += "- Plutôt de poids lourds\n"
    elif 74 <= ligne["Poids moyen"] < 77:
        texte += "- Plutôt de poids moyens\n"
    else:
        texte += "- Plutôt de poids légers\n"

    # Analyse de la taille moyenne
    if ligne["Taille moyenne"] >= 180:
        texte += "- Et de grande taille\n"
    elif ligne["Taille moyenne"] < 170:
        texte += "- Et de petite taille\n"
    else:
        texte += "- Et de taille moyenne\n"

    return texte


# -----------------------------
# Export Excel
# -----------------------------
table_periodes.to_excel(
    "output/problematique/classification_epreuves_olympiques.xlsx", index=False
)
print("Export Excel terminé : classification_epreuves_olympiques.xlsx")

# ----------------------------------------------
# Affichage concret de la typologie par cluster
# ----------------------------------------------
# Dossier de sortie
output_path = "output/problematique"
os.makedirs(output_path, exist_ok=True)

# Nom du fichier texte
output_file = os.path.join(output_path, "typologie_clusters.txt")

# Écriture dans le fichier et affichage dans la console
with open(output_file, "w", encoding="utf-8") as f:
    header = "Typologie des clusters d'épreuves sportives olympiques depuis 1896\n\n"
    f.write(header)
    print(header)
    for cluster_id in cluster_summary.index:
        interpretation = interpreter_cluster(cluster_id, cluster_summary)
        f.write(interpretation + "\n")
        print(interpretation + "\n")

print(f"Fichier texte enregistré : {output_file}")

# Construire le texte complet des clusters
typologie_text = (
    "Typologie des clusters d'épreuves sportives olympiques depuis 1896\n\n"
)
for cluster_id in cluster_summary.index:
    interpretation = interpreter_cluster(cluster_id, cluster_summary)
    typologie_text += interpretation + "\n\n"  # Pas besoin de répéter "Cluster X:"

# Mise en forme du texte pour qu'il ne dépasse pas la largeur de l'image
wrapped_text = textwrap.fill(typologie_text, width=80)

# Créer une image avec un fond clair des clusters
fig, ax = plt.subplots(figsize=(12, 10))

# Ajouter un titre principal à la figure
fig.suptitle(
    "Analyse interprétative des clusters d'épreuves olympiques pour l'ensemble"
    "des périodes",
    fontsize=16,
    fontweight="bold",
    y=0.98,  # Ajuster verticalement pour ne pas empiéter sur le texte principal
)

# Paramètres de texte
ax.axis("off")  # Masquer les axes
font_properties = {
    "verticalalignment": "top",
    "horizontalalignment": "left",
    "fontsize": 12,
}

# Texte à afficher dans l'image
y_position = 1.0  # Position verticale initiale du texte

# Définir l'espacement entre les clusters
spacing = 0.2  # Espacement entre chaque cluster

# Ajouter le texte des clusters
for cluster_id in cluster_summary.index:
    interpretation = interpreter_cluster(cluster_id, cluster_summary)

    # Ajouter la description du cluster
    ax.text(0, y_position, interpretation, **font_properties)
    y_position -= 0.1  # Espacement après la description du cluster

    # Ajouter un espace entre les clusters
    y_position -= spacing

# Sauvegarder l'image
output_image_path = "output/problematique/typologie_clusters.png"
plt.savefig(output_image_path, bbox_inches="tight", dpi=300)
if __name__ == "__main__":
    plt.show()
    plt.close()

print(f"Image enregistrée : {output_image_path}")

# Transformation du tableau cluster_summary_period en une image
# tableau qui donne la moyenne et l'écart type de
# la taille, poids et âges des athlètes
# pour chaque clusters d'épreuves sportives
fig, ax = plt.subplots(figsize=(10, 7))
ax.axis("off")  # Supprimer les axes
fig.suptitle("Résumé des clusters par période", fontsize=14, fontweight="bold")
table = ax.table(
    cellText=cluster_summary_period.values,
    colLabels=cluster_summary_period.columns,
    rowLabels=cluster_summary_period.index,
    loc="center",
    cellLoc="center",
)
table.auto_set_font_size(False)
table.set_fontsize(9)
table.scale(0.8, 0.8)

# Sauvegarde en mémoire
buf = io.BytesIO()
plt.savefig(buf, format="png", bbox_inches="tight")
buf.seek(0)

# Ouvrir l'image avec PIL
img = Image.open(buf)
if __name__ == "__main__":
    plt.show()
    plt.close()
