import pandas as pd


# -----------------------------
# Correction des données pour distinguer les épreuves individuelles et collectives,
# onn suppose qu’une épreuve est collective si elle attribue ≥ 6 médailles
def ajouter_type_epreuve(donnees):
    corrected_rows = []
    for event, group in donnees.groupby("Event"):
        medal_counts = group["Medal"].value_counts()
        total_medals = medal_counts.sum()

        if total_medals >= 6:
            kept_medals = []
            for medal in ["Gold", "Silver", "Bronze"]:
                if medal in group["Medal"].values:
                    first_occurrence = group[group["Medal"] == medal].iloc[[0]]
                    kept_medals.append(first_occurrence)
            if kept_medals:
                corrected_rows.append(pd.concat(kept_medals))
        else:
            corrected_rows.append(group)

    donnees_corr = pd.concat(corrected_rows, ignore_index=True)
    donnees_corr["Type"] = "individuel"
    epreuves_collectives = donnees_corr["Event"].value_counts()
    epreuves_collectives = epreuves_collectives[epreuves_collectives >= 6].index
    donnees_corr.loc[donnees_corr["Event"].isin(epreuves_collectives), "Type"] = (
        "collectif"
    )
    return donnees_corr


# Chaque ligne représente une épreuve. Pour chaque épreuve, on calcule des variables
# statistiques qui vont servir de caractéristiques pour la classification
def construire_table_epreuves(donnees):
    table = donnees.groupby("Event").agg(
        {
            "Sport": "first",
            "ID": "nunique",
            "NOC": "nunique",
            "Sex": lambda x: (x == "F").sum() / len(x),
            "Age": ["mean", "std"],
            "Weight": ["mean", "std"],
            "Height": ["mean", "std"],
            "Year": "min",
            "Type": "first",
        }
    )

    table.columns = [
        "Sport",
        "Nb participants",
        "Nb pays",
        "Part femmes",
        "Âge moyen",
        "Écart âge",
        "Poids moyen",
        "Écart poids",
        "Taille moyenne",
        "Écart taille",
        "Année apparition",
        "Type",
    ]
    table = table.reset_index()
    table["Nb épreuves dans le sport"] = table.groupby("Sport")["Event"].transform(
        "count"
    )
    table["Type collectif"] = (table["Type"] == "collectif").astype(int)
    return table


# -----------------------------
# Traitement par période
# -----------------------------
# les statistiques qui vont servir de caractéristiques (features) pour la classification
colonnes_features = [
    "Nb épreuves dans le sport",
    "Nb participants",
    "Nb pays",
    "Part femmes",
    "Âge moyen",
    "Écart âge",
    "Poids moyen",
    "Écart poids",
    "Taille moyenne",
    "Écart taille",
]

colonnes_features += ["Année apparition"]
colonnes_features += ["Type collectif"]

# écoupage en 4 périodes de 25 ans
periodes = {
    "1916-1940": (1916, 1940),
    "1941-1965": (1941, 1965),
    "1966-1990": (1966, 1990),
    "1991-2016": (1991, 2016),
}
