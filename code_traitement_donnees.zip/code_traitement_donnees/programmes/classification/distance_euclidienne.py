import numpy as np


def distances_individus_a_barycentres(df, barycentres):
    """
    Calcule la distance euclidienne de chaque individu (ligne)
    pour plusieurs variables dans une dataframe
    en fonction d'une liste de barycentres donnés.

    Parameters:
    -----------
        df (pd.DataFrame) : Données numériques
        barycentres (pd.DataFrame) : DataFrame contenant les barycentres
        (lignes = barycentres, colonnes = variables)

    Return:
    -------
        np.ndarray : Tableau de distances,
        lignes : individus, colonnes : barycentres
    """
    # Si la DataFrame des barycentres est vide, choisir un individu au hasard
    if barycentres.empty:
        # Choisir un individu au hasard dans le DataFrame
        barycentres = df.sample(n=1)

    # Initialiser un tableau de distances
    distances = np.zeros((df.shape[0], barycentres.shape[0]))

    # Calculer la distance pour chaque barycentre
    # itertuples pour éviter l'indexation
    for i, barycentre in enumerate(barycentres.itertuples(index=False, name=None)):

        # Calculer la distance euclidienne
        distances[:, i] = np.sqrt(((df - np.array(barycentre)) ** 2).sum(axis=1))

    return distances
