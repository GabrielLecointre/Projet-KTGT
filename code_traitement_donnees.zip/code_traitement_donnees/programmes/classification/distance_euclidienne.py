import numpy as np


def distances_individus_a_barycentres(df, barycentres):
    """
    Calcule la distance euclidienne de chaque individu (ligne)
    pour plusieurs variables dans une DataFrame en fonction d'une liste de barycentres
    donnés.

    Cette fonction calcule les distances entre chaque individu de la DataFrame `df` et
    chaque barycentre fourni dans la DataFrame `barycentres`. Elle utilise la distance
    euclidienne pour mesurer la proximité entre un individu et un barycentre dans
    l'espace multidimensionnel des variables.

    Parameters:
    -----------
    df : pd.DataFrame
        DataFrame contenant les données numériques des individus.
        Chaque ligne représente un individu, et chaque colonne représente une variable
        (caractéristique).

    barycentres : pd.DataFrame
        DataFrame contenant les barycentres des clusters.
        Chaque ligne représente un barycentre, et chaque colonne correspond à une
        variable.

    Return:
    -------
    np.ndarray
        Un tableau de distances, où chaque ligne représente un individu et chaque
        colonne représente un barycentre.
        La valeur dans le tableau à la position (i, j) correspond à la distance
        euclidienne entre l'individu `i` et le barycentre `j`.

    Example:
    --------
    distances = distances_individus_a_barycentres(df, barycentres)
    """

    # Si la DataFrame des barycentres est vide, choisir un individu au hasard pour
    # initialiser les barycentres
    if barycentres.empty:
        # Choisir un individu au hasard dans le DataFrame
        barycentres = df.sample(n=1)

    # Initialiser un tableau de distances de dimensions (nombre d'individus, nombre de
    # barycentres)
    distances = np.zeros((df.shape[0], barycentres.shape[0]))

    # Calculer la distance euclidienne pour chaque barycentre
    # Utilisation de itertuples pour éviter l'indexation par ligne
    for i, barycentre in enumerate(barycentres.itertuples(index=False, name=None)):

        # Calcul de la distance euclidienne entre chaque individu et le barycentre
        distances[:, i] = np.sqrt(((df - np.array(barycentre)) ** 2).sum(axis=1))

    # Retourner le tableau des distances
    return distances
