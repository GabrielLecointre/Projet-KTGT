''''
Le programme a pour but de déterminer le nombre optimal de clusters pour l'algorithme
K-means en utilisant la méthode du critère du coude. Cette méthode consiste à mesurer
l'inertie intra-classe (ou variance intra-cluster) pour différents nombres de clusters
et à observer où l'ajout de clusters supplémentaires n'améliore plus significativement
la qualité du clustering. Ce point est appelé "le coude".
'''
# Importation des bibliothèques nécessaires
from algo_kmeans import kmeans
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from donnees_classification import ajouter_type_epreuve as ajouter_type_epreuve
from donnees_classification import construire_table_epreuves as construire_table_epreuves
from reduction_dimension import reduction_dimension
import os

# Chargement et préparation des données
df = pd.read_csv('donnees/athlete_events.csv')

# Ajout des variables d'intérêts pour la classification
base_classification = ajouter_type_epreuve(df)
base_classification = construire_table_epreuves(base_classification)

# Suppression des variables qualitatives qui ne sont pas pertinentes pour le clustering
base_classification = base_classification.drop(['Sport', 'Event', 'Type',
    'Type collectif', 'Année apparition'], axis=1)

# Suppression des variables dépendantes qui ne doivent pas être prises en compte dans le clustering
base_classification = base_classification.drop(["Écart taille", "Écart poids", "Écart âge"], axis=1)

# Suppression de variables d'intérêt qui n'ajoutent pas de valeur pour l'analyse
base_classification = base_classification.drop([ "Nb participants", "Nb pays"], axis=1)

# Suppression des lignes contenant des valeurs manquantes
base_classification = base_classification.dropna()

# Réduction de la dimensionnalité à 2 dimensions (pour faciliter la visualisation)
base_classification = reduction_dimension(base_classification, 2)[0]

# Initialisation du nombre maximal de clusters pour l'algorithme K-means
K = 6

# Liste pour stocker l'inertie intra-classe pour chaque valeur de k
inertie_intra = []

# Boucle pour tester différents nombres de clusters (de 1 à K)
for k in range(1, K+1):
    # Appel à l'algorithme K-means avec une tolérance de 0.005 et un maximum de 6 itérations
    # Le 3e élément retourné par kmeans est l'inertie intra-classe
    inertie_intra.append(kmeans(base_classification, k, 0.005, 6)[2])

# Somme des inerties intra-classe de tous les clusters de 1 à K classes
somme_intertie = np.sum(inertie_intra)

# Normalisation de l'inertie intra-classe pour comparer les différentes valeurs de K
inertie_intra_prop = np.round(inertie_intra / inertie_intra[0] * 100)

# Affichage des inerties normalisées pour chaque nombre de clusters
print(inertie_intra_prop)

# Tracer la courbe du critère du coude (méthode Elbow)
# Définition de la taille de la figure
plt.figure(figsize=(8, 6))

# Tracer la courbe avec des marqueurs pour chaque k
plt.plot(range(1, K+1), inertie_intra_prop, marker='o')

# Ajouter un titre au graphique
plt.title("Critère du Coude pour l'ensemble des périodes")

# Label de l'axe des x (nombre de clusters)
plt.xlabel('Nombre de clusters')

# Label de l'axe des y (inertie normalisée)
plt.ylabel('Inertie totale normalisée')

# Ajouter une grille pour améliorer la lisibilité
plt.grid(True)

# Vérification si le répertoire 'output' existe, sinon le créer
output_dir = 'output/problematique'
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# Enregistrer le graphique dans le répertoire 'output'
graph_path = os.path.join(output_dir, 'critere_coude.png')
plt.savefig(graph_path)

# Affichage du graphique
plt.show()
