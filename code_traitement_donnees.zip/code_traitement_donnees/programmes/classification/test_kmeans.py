from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from algo_kmeans import kmeans
import pandas as pd
import matplotlib.pyplot as plt


def comparaison_kmeans(df: pd.DataFrame, n_clusters: int = 3, max_iter: int = 5, seuil: float = 0.005):
    """
    Compare les résultats de l'algorithme KMeans personnalisé avec ceux de KMeans de
    scikit-learn sur un sous-ensemble de données des athlètes (âge, taille, poids).
    Les résultats sont comparés et enregistrés dans un fichier CSV et affichés
    sous forme de tableau.

    L'algorithme KMeans personnalisé (défini dans algo_kmeans.py) est comparé avec le
    KMeans de scikit-learn sur les mêmes données, en utilisant les mêmes paramètres de
    nombre de clusters et d'itérations.

    Parameters:
    -----------
    df : pd.DataFrame
        Le DataFrame contenant les données (doit contenir des colonnes numériques comme
        'Age', 'Height', 'Weight').

    n_clusters : int, optional, default=3
        Le nombre de clusters à créer avec les deux algorithmes KMeans.

    max_iter : int, optional, default=5
        Le nombre maximal d'itérations à utiliser pour l'algorithme KMeans personnalisé.

    seuil : float, optional, default=0.005
        Le seuil de tolérance pour la convergence dans l'algorithme KMeans personnalisé.

    Return:
    -------
    None
        La fonction ne retourne rien, mais elle sauvegarde et affiche les résultats :
        - Un fichier CSV avec les comparaisons des classes obtenues par les deux KMeans.
        - Un graphique de type tableau comparant les classes des deux modèles.
    """

    # Préparation des données pour l'analyse
    df = df[['Age', 'Height', 'Weight']]  # Sélection des colonnes d'intérêt
    df = df.dropna()  # Suppression des lignes avec des valeurs manquantes
    df = df.head(50)  # Limitation à 50 premiers individus pour le test

    # Renormalisation des données (mise à l'échelle des caractéristiques)
    scaler = StandardScaler()
    df_scaled = scaler.fit_transform(df)

    # Application de KMeans de scikit-learn
    kmeans_sklearn = KMeans(n_clusters=n_clusters, random_state=42, n_init='auto')
    kmeans_sklearn.fit(df_scaled)

    # Résultats de scikit-learn
    # Ajustement de l'offset des classes (ajouter 1 pour correspondre à l'indexation de l'algorithme personnalisé)
    df['classe_sklearn'] = kmeans_sklearn.labels_ + 1

    # Application de l'algorithme KMeans personnalisé
    df['classe_perso'] = kmeans(df, n_clusters, seuil, max_iter)[0]['classe']

    # Calcul de la différence entre les classes des deux modèles
    df['diff'] = df['classe_sklearn'] - df['classe_perso']

    # Affichage des résultats de comparaison
    print(df[['classe_sklearn', 'classe_perso', 'diff']])

    # Sauvegarde des résultats dans un fichier CSV
    with open("output/problematique/kmeansPerso_VS_kmeansSklearn.csv", "w", encoding="utf-8") as f:
        f.write("# Comparaison des classes : KMeans sklearn vs KMeans perso\n")
        df.to_csv(f, index=False)

    # Vérification si les deux modèles concordent parfaitement
    if (df['diff'] == 0).all():
        print("Les deux modèles concordent parfaitement.")
    else:
        print("Il y a des divergences entre les deux modèles.")

    # Sélection des colonnes à afficher pour la comparaison
    table_data = df[['classe_sklearn', 'classe_perso', 'diff']]

    # Création de la figure et du tableau de comparaison
    fig, ax = plt.subplots(figsize=(6, len(table_data)*0.2))
    ax.axis('off')  # Désactivation des axes

    # Ajout du titre et du tableau à la figure
    fig.suptitle("Comparaison des classes : KMeans sklearn vs KMeans perso", fontsize=14)
    table = ax.table(cellText=table_data.values,
                     colLabels=table_data.columns,
                     cellLoc='center',
                     loc='center',
                     colColours=['#cccccc']*3)

    # Mise en forme du tableau (optionnelle)
    table.scale(1, 1.2)  # Agrandir les lignes pour une meilleure lisibilité

    # Ajustement de la mise en page pour éviter les chevauchements
    plt.tight_layout()

    # Affichage du tableau
    plt.show()

    # Sauvegarde de l'image du tableau dans un fichier PNG
    fig.savefig("output/problematique/kmeansPerso_VS_kmeansSklearn.png", dpi=300, bbox_inches="tight")
