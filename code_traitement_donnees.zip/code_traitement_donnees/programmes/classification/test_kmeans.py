from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from algo_kmeans import kmeans
import pandas as pd

# Chargement et préparation des données pour le test
df = pd.read_csv('donnees/athlete_events.csv')
df = df[['Age', 'Height', 'Weight']]
df = df.dropna()
df = df.head(50)

# Renormalisation des données
scaler = StandardScaler()
df_scaled = scaler.fit_transform(df)

# Application du KMeans de sklearn
kmeans_sklearn = KMeans(n_clusters=3, random_state=42, n_init='auto')
kmeans_sklearn.fit(df_scaled)

# Résultats sklearn
# Pour matcher l'offset +1 de ton algo
df['classe_sklearn'] = kmeans_sklearn.labels_ + 1
df['classe_perso'] = kmeans(df, 3, 0.005, 5)[0]['classe']
df['diff'] = df['classe_sklearn'] - df['classe_perso']

# Comparaison simple des labels
print(df[['classe_sklearn', 'classe_perso', 'diff']])

if (df['diff'] == 0).all():
    print("Les deux modèles concordent parfaitement.")
else:
    print("Il y a des divergences entre les deux modèles.")
