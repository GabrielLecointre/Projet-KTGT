from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from algo_kmeans import kmeans
import pandas as pd
import matplotlib.pyplot as plt

# Chargement et préparation des données pour le test
df = pd.read_csv('donnees/athlete_events.csv')
df = df[['Age', 'Height', 'Weight']]
df = df.dropna()
df = df.head(50)

# Renormalisation des données
scaler = StandardScaler()
df_scaled = scaler.fit_transform(df)

# Application du KMeans de sklearn
kmeans_sklearn = KMeans(n_clusters=3, random_state=42, n_init='auto')
kmeans_sklearn.fit(df_scaled)

# Résultats sklearn
# Pour matcher l'offset +1 de ton algo
df['classe_sklearn'] = kmeans_sklearn.labels_ + 1
df['classe_perso'] = kmeans(df, 3, 0.005, 5)[0]['classe']
df['diff'] = df['classe_sklearn'] - df['classe_perso']

# Comparaison simple des labels
print(df[['classe_sklearn', 'classe_perso', 'diff']])
# Sauvegarde
with open("output/problematique/kmeansPerso_VS_kmeansSklearn.csv", "w", encoding="utf-8") as f:
    f.write("# Comparaison des classes : KMeans sklearn vs KMeans perso\n")
    df.to_csv(f, index=False)

if (df['diff'] == 0).all():
    print("Les deux modèles concordent parfaitement.")
else:
    print("Il y a des divergences entre les deux modèles.")

# Sélection des colonnes à afficher
table_data = df[['classe_sklearn', 'classe_perso', 'diff']]

# Création de la figure et du tableau
fig, ax = plt.subplots(figsize=(6, len(table_data)*0.2))
ax.axis('off')  # Pas d'axes

fig.suptitle("Comparaison des classes : KMeans sklearn vs KMeans perso", fontsize=14)

# Ajout du tableau dans la figure
table = ax.table(cellText=table_data.values,
                 colLabels=table_data.columns,
                 cellLoc='center',
                 loc='center',
                 colColours=['#cccccc']*3)

# Mise en forme (optionnelle)
table.scale(1, 1.2)  # Agrandir les lignes

# Réajuster la mise en page
plt.tight_layout()

# Affichage
plt.show()
plt.close()

# Sauvegarde de l'image
fig.savefig("output/problematique/kmeansPerso_VS_kmeansSklearn.png", dpi=300, bbox_inches="tight")