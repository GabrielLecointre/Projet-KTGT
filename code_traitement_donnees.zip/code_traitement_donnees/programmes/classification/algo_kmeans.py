from initialisation_kmean import initialiser_barycentres
from renormalisation import renormaliser_dataframe
from distance_euclidienne import distances_individus_a_barycentres
import pandas as pd
import numpy as np


def kmeans(df: pd.DataFrame, K: int, seuil: float, max_iter: int):
    """
    Applique l'algorithme K-means sur un DataFrame.
    Les poids des variables sont supposés identitiques
    Cette fonction ne prend pas en compte les poids des variables

    Parameters :
    -----------
    df : pd.DataFrame
        Données initiales (non normalisées),
        avec uniquement des colonnes numériques.
    K : int
        Nombre de clusters à créer.
    seuil : float
        Seuil de tolérance pour la convergence
        (écart entre les deux derniers barycentres).
    max_iter : int
        Nombre maximal d'itérations à effectuer.

    Return :
    --------
    pd.DataFrame
        Le DataFrame renormalisé avec une colonne 'classe' indiquant
        l'appartenance de chaque individu à un cluster.
    pd.DataFrame
        Les barycentres des clusters finaux.
    float
        L'inertie intraclasse (somme des distances au carré des individus
        à leur barycentre).

    """

    # Étape 1 : renormalisation des données pour les mettre à
    # échelle comparable
    df_renormalise = renormaliser_dataframe(df)

    # Étape 2 : initialisation aléatoire des barycentres
    barycentres = initialiser_barycentres(df_renormalise, K, seed=42)

    # Ajout d'une colonne 'classe' initialisée à 0
    df_renormalise['classe'] = 0

    # Initialisation du critère d'arrêt et du compteur d'itérations
    arret_boucle = 1
    m = 0

    # Boucle principale de l'algorithme K-means
    while m < max_iter and arret_boucle != 0:
        m += 1  # Incrément de l'itération

        # Suppression de la colonne 'classe' pour le recalcul des distances
        df_renormalise = df_renormalise.drop(columns=["classe"])

        # Calcul des distances de chaque individu à chaque barycentre
        distances = distances_individus_a_barycentres(df_renormalise,
                                                      barycentres)

        # Attribution à la classe la plus proche (indice du barycentre minimum)
        # +1 pour démarrer à 1
        vecteur_rangs = np.argmin(distances, axis=1) + 1

        # Réintégration des classes dans le DataFrame
        df_renormalise['classe'] = vecteur_rangs

        # Sauvegarde des barycentres précédents pour évaluer la convergence
        ancien_barycentres = barycentres

        # Mise à jour des barycentres selon la nouvelle attribution
        barycentres = df_renormalise.groupby('classe').mean()
        print(ancien_barycentres)
        print(barycentres)

        # Calcul de l'écart entre anciens et nouveaux barycentres
        # lorsqu'une classe n'a pas d'individus le nombre de lignes
        # de barycentre sont différentes d'une itération à l'autre
        if ancien_barycentres.shape[0] == barycentres.shape[0]:
            conditions = abs(barycentres.values - ancien_barycentres.values)
            # Vérification de la condition d'arrêt
            condition_arret = np.min(conditions, axis=1) < seuil
            arret_boucle = np.sum(condition_arret == False)

        inertie_intra = np.sum(np.min(distances, axis=1)**2)

        # Sauvegarde du DataFrame à chaque itération (facultatif)
        df_renormalise.to_csv("output/problematique/df_renormalise.csv", index=False)

    # Retour du DataFrame final avec affectation de chaque individu à
    # un cluster
    return df_renormalise, barycentres, inertie_intra
