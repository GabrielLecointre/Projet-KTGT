from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
import pandas as pd


def reduction_dimension(base_classification, n):
    """
    Applique une réduction de dimensionnalité sur un DataFrame en utilisant
    l'Analyse en Composantes Principales (PCA), après avoir standardisé les données.

    Cette fonction permet de réduire les dimensions des données tout en préservant
    un maximum d'informations (variance). Les résultats incluent les nouvelles
    composantes principales, les contributions de chaque variable aux composantes,
    ainsi que la variance expliquée par chaque composante principale.

    Parameters:
    -----------
    base_classification : pd.DataFrame
        DataFrame contenant les données d'athlètes (ou toute autre donnée)
        à réduire. Les données doivent être numériques et sans valeurs manquantes.

    n : int
        Le nombre de composantes principales à conserver. Par exemple, pour
        une réduction à 2 dimensions, n=2.

    Returns:
    --------
    df_pca : pd.DataFrame
        DataFrame contenant les nouvelles données projetées sur les
        composantes principales (par défaut 2 dimensions : "PC1", "PC2").

    contributions : pd.DataFrame
        DataFrame contenant les coefficients des variables pour chaque
        composante principale. Chaque ligne correspond à une composante
        principale, et chaque colonne à une variable des données d'origine.

    explained_variance_ratio_ : np.ndarray
        Tableau contenant la proportion de variance expliquée par chaque
        composante principale.
    """

    # 1. Standardisation des données (mise à l'échelle)
    # Les données sont standardisées pour que chaque variable ait une moyenne de 0 et
    # un écart type de 1
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(base_classification)

    # 2. Application de l'Analyse en Composantes Principales (PCA)
    pca = PCA(n_components=2)  # Réduction à 2 dimensions par défaut
    X_pca = pca.fit_transform(X_scaled)

    # 3. Création d'un DataFrame avec les deux premières composantes principales
    df_pca = pd.DataFrame(X_pca, columns=["PC1", "PC2"])

    # 4. Contribution de chaque variable dans chaque composante principale
    contributions = pd.DataFrame(pca.components_, columns=base_classification.columns)

    # Sauvegarde des contributions dans un fichier CSV
    contributions.to_csv("output/problematique/contributions_var_cp.csv", index=False)

    # 5. Affichage de la contribution des variables
    print("Contributions des variables aux composantes principales :")
    print(contributions)

    # 6. Affichage de la variance expliquée par chaque composante
    print("\nVariance expliquée par chaque composante :")
    print(pca.explained_variance_ratio_)

    # Retourner les résultats
    return df_pca, contributions, pca.explained_variance_ratio_
