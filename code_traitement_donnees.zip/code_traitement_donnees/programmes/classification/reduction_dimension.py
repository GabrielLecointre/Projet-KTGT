from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
import pandas as pd


def reduction_dimension(base_classification, n):

    # Standardisation des données (mise à l'échelle)
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(base_classification)

    # Appliquer PCA
    pca = PCA(n_components=2)  # Par exemple, réduire à 2 dimensions
    X_pca = pca.fit_transform(X_scaled)

    # Créer un DataFrame avec les composantes principales
    df_pca = pd.DataFrame(X_pca, columns=["PC1", "PC2"])

    # Obtenir la contribution de chaque variable dans chaque composante principale
    contributions = pd.DataFrame(pca.components_, columns=base_classification.columns)
    # Sauvegarde
    contributions.to_csv("output/problematique/contributions_var_cp.csv", index=False)

    # Afficher la contribution des variables
    print("Contributions des variables aux composantes principales :")
    print(contributions)

    # Afficher la variance expliquée par chaque composante
    print("\nVariance expliquée par chaque composante :")
    print(pca.explained_variance_ratio_)

    return df_pca, contributions, pca.explained_variance_ratio_
