def renormaliser_dataframe(df):
    """
    Renormalise un DataFrame en utilisant le z-score :
    (valeur - moyenne) / écart-type pour chaque colonne.

    Parameters:
    -----------
        df (pd.DataFrame) : Données à renormaliser

    Return:
    -------
        pd.DataFrame : DataFrame renormalisé
    """
    moyennes = df.mean()
    ecarts_types = df.std()

    if (ecarts_types == 0).any():
        raise ValueError("Une ou plusieurs colonnes ont un écart-type nul.")

    df_renormalise = (df - moyennes) / ecarts_types
    return df_renormalise
