def renormaliser_dataframe(df):
    """
    Renormalise un DataFrame en utilisant la méthode du z-score pour chaque colonne :
    (valeur - moyenne) / écart-type. Cette technique de normalisation est utile
    lorsque les variables ont des échelles différentes et permet de les comparer
    sur une échelle standardisée avec une moyenne de 0 et un écart-type de 1.

    Parameters:
    -----------
    df : pd.DataFrame
        DataFrame contenant des données numériques. Les colonnes doivent être
        des variables numériques, et aucune valeur manquante ne doit être présente.

    Return:
    -------
    pd.DataFrame
        DataFrame renormalisé où chaque valeur a été transformée en z-score,
        avec une moyenne de 0 et un écart-type de 1 pour chaque colonne.

    Raise:
    ------
    ValueError
        Si une ou plusieurs colonnes ont un écart-type nul (ce qui rend la
        normalisation impossible), une erreur est levée.
    """
    # Calcul de la moyenne et de l'écart-type pour chaque colonne
    moyennes = df.mean()
    ecarts_types = df.std()

    # Vérification si une ou plusieurs colonnes ont un écart-type nul
    if (ecarts_types == 0).any():
        raise ValueError("Une ou plusieurs colonnes ont un écart-type nul.")

    # Renormalisation des données en appliquant la formule du z-score
    df_renormalise = (df - moyennes) / ecarts_types
    return df_renormalise
