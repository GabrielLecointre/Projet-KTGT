import numpy as np
import pandas as pd


def initialiser_barycentres(df: pd.DataFrame, K: int, seed: int = 42):
    """
    Sélectionne aléatoirement K individus du DataFrame comme barycentres pour
    initialiser l'algorithme de K-means.

    Cette fonction choisit K individus au hasard dans le DataFrame `df` et les
    utilise comme barycentres initiaux pour l'algorithme K-means. La sélection des
    individus est effectuée de manière aléatoire, et une graine (seed)
    peut être spécifiée pour assurer la reproductibilité des résultats.

    Parameters:
    -----------
    df : pd.DataFrame
        DataFrame contenant les individus. Chaque ligne représente un individu et
        chaque colonne représente une
        caractéristique/variable.

    K : int
        Le nombre de barycentres (ou clusters) à initialiser. Cela détermine le nombre
        de points sélectionnés
        aléatoirement dans le DataFrame `df`.

    seed : int, optionnel, défaut=42
        La graine pour l'initialisation aléatoire. Elle permet de rendre la sélection
        des barycentres reproductible en utilisant la même valeur pour `seed` dans des
        exécutions différentes. Si `None` est spécifié, la graine sera choisie
        aléatoirement.

    Return:
    -------
    pd.DataFrame
        Un DataFrame de forme (K, n_features), où K est le nombre de barycentres
        (clusters), et n_features est le nombre de caractéristiques des individus
        dans `df`. Ce DataFrame contient les K individus sélectionnés
        comme barycentres.

    Example:
    --------
    # Supposons un DataFrame df avec 100 individus et 5 caractéristiques
    barycentres = initialiser_barycentres(df, K=3, seed=42)
    print(barycentres)
    """
    # Initialisation de la graine aléatoire pour garantir la reproductibilité
    np.random.seed(seed)

    # Sélectionner aléatoirement K indices uniques dans le DataFrame
    indices = np.random.choice(df.shape[0], size=K, replace=False)

    # Retourner les lignes correspondantes aux indices sélectionnés comme barycentres
    return df.iloc[indices].copy()
