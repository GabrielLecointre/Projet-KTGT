import numpy as np
import pandas as pd


def initialiser_barycentres(df: pd.DataFrame, K: int, seed: int = 42):
    """
    Sélectionne aléatoirement k individus du DataFrame comme barycentres.

    Parameters:
    -----------
        df (pd.DataFrame) : Données contenant les individus
        k (int) : Nombre de barycentres (clusters)
        random_state (int ou None) : Graine aléatoire pour reproductibilité

    Return:
    -------
        pd.DataFrame : DataFrame de forme (k, n_features) contenant les
        barycentres
    """
    np.random.seed(seed)
    indices = np.random.choice(df.shape[0], size=K, replace=False)
    return df.iloc[indices].copy()
