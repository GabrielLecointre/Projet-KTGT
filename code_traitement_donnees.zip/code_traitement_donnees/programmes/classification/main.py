from donnees_classification import ajouter_type_epreuve
from donnees_classification import construire_table_epreuves
from reduction_dimension import reduction_dimension
import pandas as pd
from algo_kmeans import kmeans
import matplotlib.pyplot as plt
import os


def main():
    """
    Fonction principale pour effectuer la préparation des données, appliquer
    l'algorithme K-means sur les données d'athlètes et visualiser les résultats de la
    classification.

    Ce script inclut les étapes suivantes :
    1. Chargement et préparation des données d'événements des athlètes.
    2. Application de transformations sur les données pour formater et réduire les
    dimensions.
    3. Application de l'algorithme K-means pour effectuer une classification des
    athlètes.
    4. Visualisation des résultats sous forme de graphique projeté sur les deux
    premières composantes principales.
    5. Sauvegarde du graphique dans un répertoire spécifié.

    Le code s'assure que le répertoire de sortie existe, sinon il le crée et enregistre
    le graphique généré.
    """

    # Chargement et préparation des données
    df = pd.read_csv('donnees/athlete_events.csv')

    # Construction des variables d'intérêt via les fonctions du module donnees_classification
    base_classification = ajouter_type_epreuve(df)
    base_classification = construire_table_epreuves(base_classification)

    # Suppression des variables qualitatives qui ne sont pas nécessaires pour l'analyse
    base_classification = base_classification.drop(['Sport', 'Event', 'Type',
    'Type collectif', 'Année apparition'], axis=1)

    # Suppression des valeurs manquantes
    base_classification = base_classification.dropna()

    # Réduction de la dimensionnalité à 2 composantes principales pour une visualisation plus facile
    base_classification = reduction_dimension(base_classification, 2)[0]

    # Application de l'algorithme K-means sur les données, avec 3 clusters, une tolérance de 0.005 et un max de 10 itérations
    classes = kmeans(base_classification, 3, 0.005, 10)

    # Visualisation des résultats sous forme de graphique
    plt.figure(figsize=(10, 8))
    scatter = plt.scatter(classes[0]['PC1'], classes[0]['PC2'], c=classes[0]['classe'], cmap='viridis', s=50)
    plt.title("Projection des données sur les 2 premières composantes principales pour l'ensemble des périodes")
    plt.xlabel("PC1")
    plt.ylabel("PC2")
    plt.colorbar(scatter, label="Classe")

    # Vérification de l'existence du répertoire 'output/problematique' pour sauvegarder le graphique
    output_dir = 'output/problematique'
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    # Enregistrement du graphique sous forme de fichier PNG dans le répertoire output
    graph_path = os.path.join(output_dir, 'graphique_projection.png')
    plt.savefig(graph_path)

    # Affichage du graphique généré
    plt.show()

if __name__ == "__main__":
    # Exécution de la fonction principale
    main()
