from donnees_classification import ajouter_type_epreuve
from donnees_classification import construire_table_epreuves
from reduction_dimension import reduction_dimension
import pandas as pd
from algo_kmeans import kmeans
import matplotlib.pyplot as plt
import os

# Chargement et préparation des données
df = pd.read_csv('donnees/athlete_events.csv')

# construction des variables d'intérêts
base_classification = ajouter_type_epreuve(df)
base_classification = construire_table_epreuves(base_classification)

# suppression des variables qualitatives
base_classification = base_classification.drop(['Sport', 'Event', 'Type',
'Type collectif', 'Année apparition'], axis=1)
base_classification = base_classification.dropna()
base_classification = reduction_dimension(base_classification, 2)[0]

# application de l'aglo du kmeans à notre base de données
classes = kmeans(base_classification, 3, 0.005, 10)

# Visualisation
plt.figure(figsize=(10, 8))
scatter = plt.scatter(classes[0]['PC1'], classes[0]['PC2'], c=classes[0]['classe'], cmap='viridis', s=50)
plt.title("Projection des données sur les 2 premières composantes principales")
plt.xlabel("PC1")
plt.ylabel("PC2")
plt.colorbar(scatter, label="Classe")

# Vérifier si le répertoire output existe, sinon le créer
output_dir = 'output/problematique'
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# Enregistrer le graphique dans le répertoire output
graph_path = os.path.join(output_dir, 'graphique_projection.png')
plt.savefig(graph_path)

if __name__ == "__main__":
    plt.show()
