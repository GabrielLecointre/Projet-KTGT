import pandas as pd


# Charger les données
df = pd.read_csv("donnees/athlete_events.csv")  # Remplacez par le chemin correct

# Création d’un ExcelWriter pour exporter plusieurs feuilles
with pd.ExcelWriter("output/analyse_donnees/analyse_olympique.xlsx", engine='xlsxwriter') as writer:

    # Aperçu
    df.head().to_excel(writer, sheet_name='Aperçu', index=False)

    # Info générale : types et non-null
    info_df = pd.DataFrame({
        "Colonne": df.columns,
        "Type": df.dtypes.values,
        "Valeurs non nulles": df.notnull().sum().values,
        "Valeurs manquantes": df.isnull().sum().values
    })
    info_df.to_excel(writer, sheet_name='Informations', index=False)

    # Statistiques descriptives
    df.describe(include='all').transpose().to_excel(writer, sheet_name='Statistiques')

    # Valeurs uniques
    unique_df = pd.DataFrame({
        "Colonne": df.columns,
        "Valeurs uniques": [df[col].nunique() for col in df.columns]
    })
    unique_df.to_excel(writer, sheet_name='Valeurs uniques', index=False)

print("Analyse exportée dans 'analyse_olympique.xlsx'")
