"""
Ce script charge un fichier CSV contenant les données des événements olympiques et
exporte plusieurs analyses dans un fichier Excel. Les analyses incluent un aperçu des
données, des informations générales sur les colonnes, des statistiques descriptives,
et le nombre de valeurs uniques dans chaque colonne.

Étapes du script :
1. Chargement des données depuis un fichier CSV.
2. Exportation d'un aperçu des 5 premières lignes des données.
3. Génération d'un tableau d'informations générales sur chaque colonne, incluant le
type de données et le nombre de valeurs manquantes/non manquantes.
4. Calcul et exportation des statistiques descriptives sur les données, incluant toutes
les colonnes (numériques et catégorielles).
5. Calcul et exportation du nombre de valeurs uniques par colonne.
6. Sauvegarde de toutes ces informations dans un fichier Excel avec plusieurs feuilles.

Le fichier Excel final est enregistré sous le nom 'analyse_olympique.xlsx' dans le
répertoire 'output/analyse_donnees'.

Modules utilisés :
- pandas : pour le traitement des données.
- xlsxwriter : pour l'exportation des données dans un fichier Excel.

Fichier de sortie :
- 'analyse_olympique.xlsx' contenant plusieurs feuilles : 'Aperçu', 'Informations',
'Statistiques', 'Valeurs uniques'.
"""
import pandas as pd

# Charger les données à partir du fichier CSV
# Remplacez par le chemin correct du fichier CSV
df = pd.read_csv("donnees/athlete_events.csv")

# Création d’un ExcelWriter pour exporter plusieurs feuilles dans un fichier Excel
with pd.ExcelWriter("output/analyse_donnees/analyse_olympique.xlsx", engine='xlsxwriter') as writer:

    # Aperçu des 5 premières lignes du DataFrame
    df.head().to_excel(writer, sheet_name='Aperçu', index=False)

    # Création d'un DataFrame contenant des informations générales sur les colonnes du
    # DataFrame. Cela inclut le type de données de chaque colonne, le nombre de valeurs
    # non nulles et manquantes
    info_df = pd.DataFrame({
        # Noms des colonnes
        "Colonne": df.columns,
        # Types de données des colonnes
        "Type": df.dtypes.values,
        # Nombre de valeurs non nulles par colonne
        "Valeurs non nulles": df.notnull().sum().values,
        # Nombre de valeurs manquantes par colonne
        "Valeurs manquantes": df.isnull().sum().values
    })
    # Exporter ce tableau dans une feuille Excel appelée 'Informations'
    info_df.to_excel(writer, sheet_name='Informations', index=False)

    # Statistiques descriptives sur les données, incluant toutes les colonnes
    # (numériques et catégorielles)
    # Les statistiques sont transposées pour une meilleure lisibilité
    df.describe(include='all').transpose().to_excel(writer, sheet_name='Statistiques')

    # Création d'un DataFrame contenant le nombre de valeurs uniques dans chaque colonne
    unique_df = pd.DataFrame({
        # Noms des colonnes
        "Colonne": df.columns,
        # Nombre de valeurs uniques dans chaque colonne
        "Valeurs uniques": [df[col].nunique() for col in df.columns]
    })
    # Exporter ce tableau dans une feuille Excel appelée 'Valeurs uniques'
    unique_df.to_excel(writer, sheet_name='Valeurs uniques', index=False)

# Message de confirmation une fois l'exportation terminée
print("Analyse exportée dans 'analyse_olympique.xlsx'")
