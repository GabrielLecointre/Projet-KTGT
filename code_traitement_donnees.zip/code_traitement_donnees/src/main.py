"""
Interface principale de navigation des questions du projet de traitement de données.

Cette interface graphique, développée avec Tkinter, permet à l'utilisateur de
sélectionner une question ou une fonctionnalité (k-means, critère du coude,
classification...) via un menu déroulant, puis de lancer les modules correspondants.

Les questions 1 à 4 ouvrent des interfaces dédiées. Les autres scripts s'exécutent dans
la console après la fermeture d'une fenêtre d'information.

Modules appelés :
- interface_graphique.interface_question1 à 4 pour les interfaces dédiées
- subprocess pour exécuter les scripts externes
- threading pour éviter de bloquer l'interface principale

Auteurs : Téodora, Gabriel, Tual, Khalid
"""

import tkinter as tk
from tkinter import ttk
from interface_graphique.interface_question3 import lancer_interface_q3
from interface_graphique.interface_question4 import lancer_interface_q4
import subprocess
import os
import threading


def afficher_question(event):
    """
    Gère la sélection d'une question dans le menu déroulant et appelle le module approprié.

    :param event: Événement déclenché par la sélection dans le menu déroulant.
    """
    question_selectionnee = combo_question.get()
    label_resultat.config(text=f"Vous avez sélectionné : {question_selectionnee}")

    if question_selectionnee == "Classification":
        afficher_message_et_lancer_script("main.py", "Classification")
    elif question_selectionnee == "Critere_coude":
        afficher_message_et_lancer_script("critere_coude.py", "Critere_coude")
    elif question_selectionnee == "Test_kmeans":
        afficher_message_et_lancer_script("test_kmeans.py", "Test_kmeans")
    elif question_selectionnee == "Tests_execution":
        afficher_message_et_lancer_script("tests_execution.py", "Tests_execution")
    elif question_selectionnee == "Question 1":
        afficher_message_et_lancer_script("interface_question1.py", "Question 1")
    elif question_selectionnee == "Question 2":
        afficher_message_et_lancer_script("interface_question2.py", "Question 2")
    elif question_selectionnee == "Question 3":
        lancer_interface_q3()
    elif question_selectionnee == "Question 4":
        lancer_interface_q4()
    elif question_selectionnee == "Question 5":
        afficher_message_et_lancer_script("question5_pandapython.py", "Question 5")
    elif question_selectionnee == "Question 6":
        afficher_message_et_lancer_script("question6_pandapython.py", "Question 6")
    elif question_selectionnee == "Question 7":
        afficher_message_et_lancer_script("question7_pandapython.py", "Question 7")
    elif question_selectionnee == "Question 8":
        afficher_message_et_lancer_script("question8_pandapython.py", "Question 8")
    elif question_selectionnee == "Question 9":
        afficher_message_et_lancer_script("question9_pandapython.py", "Question 9")


def afficher_message_et_lancer_script(nom_fichier, question):
    """
    Affiche un message d'instruction à l'utilisateur, puis exécute le script
    correspondant dans un thread séparé.

    :param nom_fichier: Nom du script Python à exécuter
    :param question: Nom ou identifiant de la question ou fonctionnalité sélectionnée
    """

    if question in ("Classification", "Critere_coude", "Test_kmeans"):
        repertoire = r"programmes/classification"
        message = "Fermer la fenêtre et attendre que le(s) graphique(s) s'affiche(nt)."
    elif question in ("Question 5", "Question 6", "Question 7", "Question 8", "Question 9"):
        repertoire = r"programmes/questions/questions_pandapython"
        message = "Fermer la fenêtre et suivre les instructions de la console."
    elif question == "Tests_execution":
        repertoire = r"src/tests"
        message = "Fermer la fenêtre et suivre les instructions de la console."
    elif (question == "Question 1") or ("Question 2"):
        repertoire = r"src/interface_graphique"
        message = "¨Patienter, une fenêtre Tinker va s'ouvrir."

    # Fenêtre de message
    fenetre = tk.Tk()
    fenetre.title("Message")

    label_message = tk.Label(fenetre, text=message, font=("Arial", 10))
    label_message.pack(pady=20)

    bouton_fermer = tk.Button(fenetre, text="Fermer", command=fenetre.destroy, font=("Arial", 10))
    bouton_fermer.pack(pady=10)

    fenetre.update()

    # Fonction pour exécuter le script
    def run_script():
        chemin_complet = os.path.join(repertoire, nom_fichier)
        subprocess.run(["python", chemin_complet])

    script_thread = threading.Thread(target=run_script)
    script_thread.start()

    fenetre.mainloop()


def quitter_application():
    """
    Ferme la fenêtre principale de l'application.
    """
    fenetre.destroy()


# Création de la fenêtre principale
fenetre = tk.Tk()
fenetre.title("Menu de Questions")
fenetre.geometry("400x300")

# Liste déroulante des options disponibles
questions = ["Tests_execution", "Test_kmeans", "Critere_coude", "Classification"] + [f"Question {i}" for i in range(1, 10)]

# Combobox (menu déroulant)
combo_question = ttk.Combobox(fenetre, values=questions, state="readonly", width=30)
combo_question.set("Choisissez une question")
combo_question.pack(pady=10)

# Label de retour visuel après sélection
label_resultat = tk.Label(fenetre, text="")
label_resultat.pack(pady=10)

# Bouton pour quitter
bouton_quitter = tk.Button(fenetre, text="Quitter", command=quitter_application, bg="red", fg="white")
bouton_quitter.pack(pady=10)

# Liaison de l'événement de sélection à la fonction
combo_question.bind("<<ComboboxSelected>>", afficher_question)

# Lancement de la boucle Tkinter
fenetre.mainloop()
