import tkinter as tk
from tkinter import ttk
from interface_graphique.interface_question1 import lancer_interface_q1  # Import de la fonction de la question 1
from interface_graphique.interface_question2 import lancer_interface_q2  # Import de la fonction de la question 2
from interface_graphique.interface_question3 import lancer_interface_q3  # Import de la fonction de la question 3
from interface_graphique.interface_question4 import lancer_interface_q4  # Import de la fonction de la question 4
import subprocess
import os
import threading


# Fonction pour afficher les questions et gérer les réponses
def afficher_question(event):
    question_selectionnee = combo_question.get()
    label_resultat.config(text=f"Vous avez sélectionné : {question_selectionnee}")

    # Ouvrir l'interface de la question sélectionnée
    if question_selectionnee == "Classification":
        afficher_message_et_lancer_script("main.py", "Classification")
    elif question_selectionnee == "Critere_coude":
        afficher_message_et_lancer_script("critere_coude.py", "Critere_coude")
    elif question_selectionnee == "Test_kmeans":
        afficher_message_et_lancer_script("test_kmeans.py", "Test_kmeans")
    elif question_selectionnee == "Tests_execution":
        afficher_message_et_lancer_script("tests_execution.py", "Tests_execution")
    elif question_selectionnee == "Question 1":
        lancer_interface_q1()
    elif question_selectionnee == "Question 2":
        lancer_interface_q2()  # Appel de la fonction pour lancer l'interface de la question 2
    elif question_selectionnee == "Question 3":
        lancer_interface_q3()  # Appel de la fonction pour lancer l'interface de la question 3
    elif question_selectionnee == "Question 4":
        lancer_interface_q4()  # Appel de la fonction pour lancer l'interface de la question 4
    elif question_selectionnee == "Question 5":
        # Répertoire où se trouvent les scripts
        afficher_message_et_lancer_script("question5_pandapython.py", "Question 5")
    elif question_selectionnee == "Question 6":
        afficher_message_et_lancer_script("question6_pandapython.py", "Question 6")
    elif question_selectionnee == "Question 7":
        afficher_message_et_lancer_script("question7_pandapython.py", "Question 7")
    elif question_selectionnee == "Question 8":
        afficher_message_et_lancer_script("question8_pandapython.py", "Question 8")
    elif question_selectionnee == "Question 9":
        afficher_message_et_lancer_script("question9_pandapython.py", "Question 9")


# Fonction pour afficher une fenêtre avec le message et lancer le script
# les saisies sont à faire sur la console et non dans la fenêtre Tkinter
def afficher_message_et_lancer_script(nom_fichier, question):

    if question in ("Classification", "Critere_coude", "Test_kmeans"):
        repertoire = r"programmes/classification"
        message = "Fermer la fenêtre et attendre que le(s) graphique(s) s'affiche(nt)"
    elif question in ("Question 5", "Question 6", "Question 7", "Question 8", "Question 9"):
        repertoire = r"programmes/questions/questions_pandapython"
        message = "Fermer la fenêtre et suivre les instructions de la console."
    elif question in ("Tests_execution"):
        message = "Fermer la fenêtre et suivre les instructions de la console."
        repertoire = r"src/tests"

    # Créer la fenêtre Tkinter
    fenetre = tk.Tk()
    fenetre.title("Message")

    # Créer un label pour afficher le message
    message = tk.Label(fenetre, text=message, font=("Arial", 10))
    message.pack(pady=20)

    # Créer un bouton pour fermer la fenêtre après avoir vu le message
    bouton_fermer = tk.Button(fenetre, text="Fermer", command=fenetre.destroy, font=("Arial", 10))
    bouton_fermer.pack(pady=10)

    # Lancer la fenêtre Tkinter
    fenetre.update()

    # Lancer le script dans un autre thread pour ne pas bloquer la fenêtre Tkinter
    def run_script():
        chemin_complet = os.path.join(repertoire, nom_fichier)
        subprocess.run(["python", chemin_complet])

    # Lancer le script dans un thread séparé
    script_thread = threading.Thread(target=run_script)
    script_thread.start()

    # Continuer d'exécuter la boucle Tkinter sans bloquer
    fenetre.mainloop()


def quitter_application():
    fenetre.destroy()
# Création de la fenêtre principale


fenetre = tk.Tk()
fenetre.title("Menu de Questions")
fenetre.geometry("400x300")

# Liste des questions
questions = ["Tests_execution"] + ["Test_kmeans"] + ["Critere_coude"] + ["Classification"] + [f"Question {i}" for i in range(1, 10)]

# Création du menu déroulant (combobox)
combo_question = ttk.Combobox(fenetre, values=questions, state="readonly", width=30)
combo_question.set("Choisissez une question")
combo_question.pack(pady=10)

# Label pour afficher la question sélectionnée
label_resultat = tk.Label(fenetre, text="")
label_resultat.pack(pady=10)

# Bouton pour quitter l'application
bouton_quitter = tk.Button(fenetre, text="Quitter", command=quitter_application, bg="red", fg="white")
bouton_quitter.pack(pady=10)

# Liaison de la sélection du menu à une fonction
combo_question.bind("<<ComboboxSelected>>", afficher_question)

# Lancement de la boucle principale
fenetre.mainloop()
