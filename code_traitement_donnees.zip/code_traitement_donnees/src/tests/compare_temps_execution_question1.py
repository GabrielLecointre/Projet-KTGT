import sys
import os

# Ajouter explicitement le dossier src au sys.path
# Obtenir le répertoire courant du script
script_dir = os.path.dirname(os.path.abspath(__file__))
# Ajouter le dossier src (parent du dossier tests) au sys.path
src_dir = os.path.abspath(os.path.join(script_dir, '..', '..'))
sys.path.insert(0, src_dir)

# Vérifier sys.path pour s'assurer que le chemin correct est ajouté
print("Chemins dans sys.path:", sys.path)

import time
from programmes.questions.questions_basepython.question1_basepython import nb_medailles_athlete as nb_medailles_basepython
from programmes.questions.questions_pandapython.question1_pandapython import nb_medailles_athlete as nb_medailles_pandapython

# Chronométrer le début pour basepython
start_time_basepython = time.time()

# Appeler la fonction nb_medailles_athlete du module basepython
nb_medailles_basepython("Michael Fred Phelps, II", 2008)

# Chronométrer la fin pour basepython
end_time_basepython = time.time()

# Chronométrer le début pour pandapython
start_time_pandapython = time.time()

# Appeler la fonction nb_medailles_athlete du module pandapython
nb_medailles_pandapython("Michael Fred Phelps, II", 2008)

# Chronométrer la fin pour pandapython
end_time_pandapython = time.time()

# Calculer les temps d'exécution
execution_time_basepython = end_time_basepython - start_time_basepython
execution_time_pandapython = end_time_pandapython - start_time_pandapython

# Afficher les résultats
print(f"Temps d'exécution de nb_medailles_athlete (basepython) : {execution_time_basepython:.6f} secondes")
print(f"Temps d'exécution de nb_medailles_athlete (pandapython) : {execution_time_pandapython:.6f} secondes")

# Comparer les deux temps d'exécution
if execution_time_basepython < execution_time_pandapython:
    print("La fonction basepython est plus rapide.")
else:
    print("La fonction pandapython est plus rapide.")
