"""
Interface graphique pour comparer les performances d'exécution entre deux implémentations
(BasePython vs PandaPython) de la fonction calculant le nombre de médailles d'un athlète pour une année donnée.

Cette interface charge les deux fonctions depuis leurs modules respectifs, exécute chacune,
mesure le temps d'exécution, puis affiche les résultats dans une interface Tkinter.
"""

import sys
import os
import time
import tkinter as tk
from tkinter import ttk

# Ajouter explicitement le dossier 'src' au chemin système pour permettre l'import
script_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.abspath(os.path.join(script_dir, '..', '..'))
sys.path.insert(0, src_dir)

# Import des fonctions depuis les modules basepython et pandapython
from programmes.questions.questions_basepython.question1_basepython import nb_medailles_athlete as nb_medailles_basepython
from programmes.questions.questions_pandapython.question1_pandapython import nb_medailles_athlete as nb_medailles_pandapython


def afficher_resultats():
    """
    Fonction principale appelée au clic sur le bouton.
    Exécute les deux implémentations de la fonction 'nb_medailles_athlete',
    mesure leur temps d'exécution et affiche les résultats dans l'interface.
    """
    athlete = "Michael Fred Phelps, II"
    annee = 2008

    # Mesure du temps pour l'implémentation BasePython
    start_time_basepython = time.time()
    nb_base = nb_medailles_basepython(athlete, annee)
    end_time_basepython = time.time()

    # Mesure du temps pour l'implémentation PandaPython
    start_time_pandapython = time.time()
    nb_panda = nb_medailles_pandapython(athlete, annee)
    end_time_pandapython = time.time()

    # Calcul des temps d'exécution
    execution_time_basepython = end_time_basepython - start_time_basepython
    execution_time_pandapython = end_time_pandapython - start_time_pandapython

    # Affichage des résultats formatés dans le label
    label_resultats.config(text=f"""
Résultats pour {athlete} ({annee}) :

BasePython :
  Médailles : {nb_base}
  Temps     : {execution_time_basepython:.6f} sec

PandaPython :
  Médailles : {nb_panda}
  Temps     : {execution_time_pandapython:.6f} sec

Conclusion : {'BasePython' if execution_time_basepython < execution_time_pandapython else 'PandaPython'} est plus rapide.
""")

# ================= Interface graphique =================

# Création de la fenêtre principale
root = tk.Tk()
root.title("Comparaison de performances")

# Label d'introduction
label_intro = ttk.Label(root, text="Cliquez pour afficher les performances de chaque méthode", font=("Arial", 12))
label_intro.pack(pady=10)

# Bouton pour lancer l'analyse
btn = ttk.Button(root, text="Afficher les résultats", command=afficher_resultats)
btn.pack(pady=10)

# Zone d'affichage des résultats
label_resultats = ttk.Label(root, text="", font=("Courier", 10), justify="left")
label_resultats.pack(padx=10, pady=10)

# Bouton de fermeture de l'application
btn_quit = ttk.Button(root, text="Fermer", command=root.destroy)
btn_quit.pack(pady=4)

# Lancement de la boucle principale Tkinter
root.mainloop()
