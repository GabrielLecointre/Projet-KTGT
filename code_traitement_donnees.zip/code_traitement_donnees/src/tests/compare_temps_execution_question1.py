import sys
import os
import time
import tkinter as tk
from tkinter import ttk

# Ajouter explicitement le dossier src au sys.path
script_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.abspath(os.path.join(script_dir, '..', '..'))
sys.path.insert(0, src_dir)

# Importer les fonctions
from programmes.questions.questions_basepython.question1_basepython import nb_medailles_athlete as nb_medailles_basepython
from programmes.questions.questions_pandapython.question1_pandapython import nb_medailles_athlete as nb_medailles_pandapython


# Fonction principale à exécuter au clic d'un bouton
def afficher_resultats():
    athlete = "Michael Fred Phelps, II"
    annee = 2008

    start_time_basepython = time.time()
    nb_base = nb_medailles_basepython(athlete, annee)
    end_time_basepython = time.time()

    start_time_pandapython = time.time()
    nb_panda = nb_medailles_pandapython(athlete, annee)
    end_time_pandapython = time.time()

    execution_time_basepython = end_time_basepython - start_time_basepython
    execution_time_pandapython = end_time_pandapython - start_time_pandapython

    label_resultats.config(text=f"""
Résultats pour {athlete} ({annee}) :

BasePython:
  Médailles : {nb_base}
  Temps : {execution_time_basepython:.6f} sec

PandaPython:
  Médailles : {nb_panda}
  Temps : {execution_time_pandapython:.6f} sec

Conclusion : {'BasePython' if execution_time_basepython < execution_time_pandapython else 'PandaPython'} est plus rapide.
""")

# Interface Tkinter
root = tk.Tk()
root.title("Comparaison de performances")

label_intro = ttk.Label(root, text="Cliquez pour afficher les performances de chaque méthode", font=("Arial", 12))
label_intro.pack(pady=10)

btn = ttk.Button(root, text="Afficher les résultats", command=afficher_resultats)
btn.pack(pady=10)

label_resultats = ttk.Label(root, text="", font=("Courier", 10), justify="left")
label_resultats.pack(padx=10, pady=10)

root.mainloop()
