import subprocess
import os

# repertoire
repertoire = r"src/tests"

# Lancer le module compare_temps_execution_question1.py
nom_fichier = "compare_temps_execution_question1.py"
chemin_complet = os.path.join(repertoire, nom_fichier)
subprocess.run(["python", chemin_complet])

# Lancer le module compare_temps_execution_question1.py
nom_fichier = "compare_temps_execution_question2.py"
chemin_complet = os.path.join(repertoire, nom_fichier)
subprocess.run(["python", chemin_complet])
