"""
Interface Tkinter pour comparer les performances entre deux implémentations
(BasePython et PandaPython) de la fonction de comptage du nombre de médailles par
pays pour une année donnée.

Les résultats affichent :
- le nombre de pays comptés,
- le temps d'exécution de chaque méthode,
- une conclusion sur laquelle est la plus rapide.
"""

import sys
import os
import time
import tkinter as tk
from tkinter import ttk

# === Configuration de l'environnement d'import ===

# Obtenir le chemin absolu du dossier courant
script_dir = os.path.dirname(os.path.abspath(__file__))
# Remonter au dossier racine du projet
src_dir = os.path.abspath(os.path.join(script_dir, '..', '..'))
# Ajouter ce dossier au chemin système pour permettre les imports personnalisés
sys.path.insert(0, src_dir)

# === Import des fonctions à comparer ===

from programmes.questions.questions_basepython.question2_basepython import compter_medailles_par_pays as compter_medailles_par_pays_basepython
from programmes.questions.questions_pandapython.question2_pandapython import compter_medailles_par_pays as compter_medailles_par_pays_pandapython


def afficher_resultats():
    """
    Fonction exécutée lorsqu'on clique sur le bouton "Afficher les résultats".
    Elle appelle les deux fonctions de comptage de médailles par pays pour l'année 2008,
    mesure leur temps d'exécution respectif et affiche les résultats dans l'interface.
    """
    annee = 2008

    # Exécution et chronométrage de l'implémentation en BasePython
    start_time_basepython = time.time()
    resultat_base = compter_medailles_par_pays_basepython(annee)
    end_time_basepython = time.time()

    # Exécution et chronométrage de l'implémentation en PandaPython
    start_time_pandapython = time.time()
    resultat_panda = compter_medailles_par_pays_pandapython(annee)
    end_time_pandapython = time.time()

    # Calcul du temps d'exécution pour chaque méthode
    execution_time_basepython = end_time_basepython - start_time_basepython
    execution_time_pandapython = end_time_pandapython - start_time_pandapython

    # Affichage des résultats dans un widget Tkinter
    label_resultats.config(text=f"""
Résultats pour l'année {annee} :

BasePython :
  Pays comptés : {len(resultat_base)}
  Temps        : {execution_time_basepython:.6f} sec

PandaPython :
  Pays comptés : {len(resultat_panda)}
  Temps        : {execution_time_pandapython:.6f} sec

Conclusion : {'BasePython' if execution_time_basepython < execution_time_pandapython else 'PandaPython'} est plus rapide.
""")


# === Construction de l'interface graphique avec Tkinter ===
if __name__ == "__main__":
    # Création de la fenêtre principale
    root = tk.Tk()
    root.title("Comparaison de performances - Médailles par pays")

    # Introduction utilisateur
    label_intro = ttk.Label(
        root,
        text="Cliquez pour comparer les performances du comptage de médailles par pays",
        font=("Arial", 12)
    )
    label_intro.pack(pady=10)

    # Bouton pour exécuter la comparaison
    btn = ttk.Button(root, text="Afficher les résultats", command=afficher_resultats)
    btn.pack(pady=10)

    # Zone d'affichage des résultats
    label_resultats = ttk.Label(root, text="", font=("Courier", 10), justify="left")
    label_resultats.pack(padx=10, pady=10)

    # Bouton pour fermer la fenêtre
    btn_quit = ttk.Button(root, text="Fermer", command=root.destroy)
    btn_quit.pack(pady=4)

    # Lancement de la boucle principale de l'application
    root.mainloop()
