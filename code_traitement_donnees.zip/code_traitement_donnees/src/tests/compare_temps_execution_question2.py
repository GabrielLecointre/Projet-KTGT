import sys
import os
import time
import tkinter as tk
from tkinter import ttk

# Ajouter explicitement le dossier src au sys.path
script_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.abspath(os.path.join(script_dir, '..', '..'))
sys.path.insert(0, src_dir)

# Importer les fonctions à comparer
from programmes.questions.questions_basepython.question2_basepython import compter_medailles_par_pays as compter_medailles_par_pays_basepython
from programmes.questions.questions_pandapython.question2_pandapython import compter_medailles_par_pays as compter_medailles_par_pays_pandapython


# Fonction appelée par le bouton
def afficher_resultats():
    annee = 2008

    start_time_basepython = time.time()
    resultat_base = compter_medailles_par_pays_basepython(annee)
    end_time_basepython = time.time()

    start_time_pandapython = time.time()
    resultat_panda = compter_medailles_par_pays_pandapython(annee)
    end_time_pandapython = time.time()

    execution_time_basepython = end_time_basepython - start_time_basepython
    execution_time_pandapython = end_time_pandapython - start_time_pandapython

    label_resultats.config(text=f"""
Résultats pour l'année {annee} :

BasePython:
  Pays comptés : {len(resultat_base)}
  Temps : {execution_time_basepython:.6f} sec

PandaPython:
  Pays comptés : {len(resultat_panda)}
  Temps : {execution_time_pandapython:.6f} sec

Conclusion : {'BasePython' if execution_time_basepython < execution_time_pandapython else 'PandaPython'} est plus rapide.
""")

# Interface Tkinter
root = tk.Tk()
root.title("Comparaison de performances - Médailles par pays")

label_intro = ttk.Label(root, text="Cliquez pour comparer les performances du comptage de médailles par pays", font=("Arial", 12))
label_intro.pack(pady=10)

btn = ttk.Button(root, text="Afficher les résultats", command=afficher_resultats)
btn.pack(pady=10)

label_resultats = ttk.Label(root, text="", font=("Courier", 10), justify="left")
label_resultats.pack(padx=10, pady=10)

root.mainloop()
