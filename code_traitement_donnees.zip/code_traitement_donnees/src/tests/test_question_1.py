import os
import sys

from programmes.questions.questions_pandapython.question1_pandapython import (
    nb_medailles_athlete,
)

# Ajouter explicitement le dossier src au sys.path
script_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.abspath(os.path.join(script_dir, "..", ".."))
sys.path.insert(0, src_dir)


def test_resultats_phelps_2008():
    # Appeler la fonction pour Michael Phelps en 2008
    resultats = nb_medailles_athlete("Michael Fred Phelps, II", 2008)

    # Vérifier que le total des médailles est bien 8
    assert (
        resultats["total_medailles"] == 8
    ), "Michael Phelps aurait dû remporter 8 médailles en 2008"

    # Vérifier que le résumé contient bien 8 médailles réparties correctement
    resume = resultats["resume"]
    assert "Gold" in resume.index, "Il manque la catégorie 'Gold' dans le résumé"
    assert (
        resume.loc["Gold", "Nombre"] == 8
    ), "Michael Phelps aurait dû remporter 8 médailles d'or en 2008"
    assert (
        "Silver" not in resume.index or resume.loc["Silver", "Nombre"] == 0
    ), "Michael Phelps n’a pas gagné d'argent en 2008"
    assert (
        "Bronze" not in resume.index or resume.loc["Bronze", "Nombre"] == 0
    ), "Michael Phelps n’a pas gagné de bronze en 2008"

    # Vérifier qu’un seul nom d’athlète est trouvé et correspond exactement
    athletes = resultats["athletes_found"]["Athlètes trouvés"].tolist()
    assert len(athletes) == 1, "Il ne devrait y avoir qu’un seul athlète trouvé"
    assert (
        athletes[0] == "Michael Fred Phelps, II"
    ), "Le nom de l’athlète trouvé ne correspond pas"
