import pandas as pd
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import sys
import os

# Ajouter explicitement le dossier src au sys.path
# Obtenir le répertoire courant du script
script_dir = os.path.dirname(os.path.abspath(__file__))
# Ajouter le dossier src (parent du dossier tests) au sys.path
src_dir = os.path.abspath(os.path.join(script_dir, '..', '..'))
sys.path.insert(0, src_dir)

from src.interface_graphique.histograme_question2 import afficher_histogramme_medailles
from programmes.questions.questions_pandapython.question2_pandapython import compter_medailles_par_pays  # Si nécessaire


# Vérifier sys.path pour s'assurer que le chemin correct est ajouté
print("Chemins dans sys.path:", sys.path)

# Charger les données (assurez-vous que le fichier est au bon endroit)
df = pd.read_csv('donnees/athlete_events.csv')
df = df[['Team', 'Year', 'Event', 'Medal']]


# Interface graphique
def lancer_interface_q2():
    root = tk.Tk()
    root.title("Analyse des Médailles Olympiques")
    root.geometry("700x600")  # Fenêtre plus large pour plus de place

    # Appliquer une couleur de fond claire
    root.configure(bg='#f0f0f0')

    # Frame pour le contenu principal
    main_frame = tk.Frame(root, bg='#f0f0f0')
    main_frame.pack(fill="both", expand=True, padx=10, pady=10)

    # Frame pour les boutons en haut
    bouton_frame = tk.Frame(main_frame, bg='#f0f0f0')
    bouton_frame.grid(row=0, column=0, sticky="ew", pady=10)

    # Sélection de l'année
    tk.Label(bouton_frame, text="Sélectionnez une année :", bg='#f0f0f0').grid(row=0, column=0, padx=5)
    annees = sorted(df['Year'].unique())
    annee_var = tk.StringVar(value=str(annees[-1]))
    annee_menu = ttk.Combobox(bouton_frame, values=annees, textvariable=annee_var, state="readonly")
    annee_menu.grid(row=0, column=1, padx=5)

    # Liste des pays (déplacée à droite)
    tk.Label(bouton_frame, text="Sélectionnez le(s) pays (Ctrl+clic pour plusieurs) :", bg='#f0f0f0').grid(row=1, column=0, padx=5)
    pays_listbox = tk.Listbox(bouton_frame, selectmode='multiple', height=5, exportselection=False)
    pays_listbox.grid(row=1, column=2, padx=5)  # Placer dans la colonne 2, à droite

    # Mise à jour de la liste des pays disponibles
    def maj_liste_pays(*args):
        pays_listbox.delete(0, tk.END)
        year = int(annee_var.get())
        pays = sorted(df[df['Year'] == year]['Team'].dropna().unique())
        pays.insert(0, 'all')
        for p in pays:
            pays_listbox.insert(tk.END, p)

    annee_menu.bind("<<ComboboxSelected>>", maj_liste_pays)
    maj_liste_pays()

    # Tableau des résultats
    columns = ['Team', 'Gold_inf', 'Silver_inf', 'Bronze_inf', 'Total_inf',
               'Gold_sup', 'Silver_sup', 'Bronze_sup', 'Total_sup']
    tree = ttk.Treeview(root, columns=columns, show='headings', height=15)
    for col in columns:
        tree.heading(col, text=col)
        tree.column(col, width=100)

    # Ajouter un Canvas avec une barre de défilement
    canvas = tk.Canvas(main_frame, bg='#f0f0f0')
    scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
    canvas.configure(yscrollcommand=scrollbar.set)

    canvas.grid(row=1, column=0, sticky="nsew")
    scrollbar.grid(row=1, column=1, sticky="ns")

    # Frame interne pour y insérer le tableau de résultats
    result_frame = tk.Frame(canvas, bg='#f0f0f0')
    canvas.create_window((0, 0), window=result_frame, anchor="nw")

    tree.pack(in_=result_frame, padx=5, pady=5)

    # Afficher les résultats
    def afficher_resultats():
        annee = int(annee_var.get())
        selection = [pays_listbox.get(i) for i in pays_listbox.curselection()]
        team = 'all' if 'all' in selection or not selection else selection

        try:
            resultats = compter_medailles_par_pays(annee, team)
        except ValueError as e:
            messagebox.showerror("Erreur", str(e))
            return

        for i in tree.get_children():
            tree.delete(i)

        for _, row in resultats.iterrows():
            tree.insert('', tk.END, values=[row.get(col, 0) for col in columns])

        result_frame.update_idletasks()
        canvas.config(scrollregion=canvas.bbox("all"))  # Actualiser la zone de défilement

    bouton_afficher = tk.Button(bouton_frame, text="Afficher les résultats", command=afficher_resultats, bg='#4CAF50', fg='white', relief="solid")
    bouton_afficher.grid(row=0, column=2, padx=10)

    # Quitter l'application
    def quitter():
        root.destroy()

    bouton_quitter = tk.Button(bouton_frame, text="Quitter", command=quitter, bg='#FF6347', fg='white', relief="solid")
    bouton_quitter.grid(row=0, column=3, padx=10)

    def afficher_histogramme():
        annee = int(annee_var.get())
        selection = [pays_listbox.get(i) for i in pays_listbox.curselection()]
        team = 'all' if 'all' in selection or not selection else selection

        try:
            resultats = compter_medailles_par_pays(annee, team)
            pass  # nécessaire pour que les ticks soient corrects
            afficher_histogramme_medailles(resultats)
        except ValueError as e:
            messagebox.showerror("Erreur", str(e))

    bouton_histogramme = tk.Button(bouton_frame, text="Afficher l'histogramme", command=afficher_histogramme, bg='#FFA500', fg='white', relief="solid")
    bouton_histogramme.grid(row=0, column=5, padx=10)

    # Enregistrer les résultats
    def enregistrer_resultats():
        annee = int(annee_var.get())
        selection = [pays_listbox.get(i) for i in pays_listbox.curselection()]
        team = 'all' if 'all' in selection or not selection else selection

        try:
            resultats = compter_medailles_par_pays(annee, team)
        except ValueError as e:
            messagebox.showerror("Erreur", str(e))
            return

        # Ouvrir la boîte de dialogue pour choisir le fichier
        fichier = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files", "*.csv")])
        if fichier:
            resultats.to_csv(fichier, index=False)
            messagebox.showinfo("Succès", "Les résultats ont été enregistrés avec succès!")

    bouton_enregistrer = tk.Button(bouton_frame, text="Enregistrer les résultats", command=enregistrer_resultats, bg='#007BFF', fg='white', relief="solid")
    bouton_enregistrer.grid(row=0, column=4, padx=10)

    # Configurer les colonnes de la grille
    root.grid_rowconfigure(1, weight=1)
    root.grid_columnconfigure(0, weight=1)

    root.mainloop()
