"""
Interface graphique pour l'analyse des médailles olympiques par pays et par année.
Ce module permet de sélectionner une année et un ou plusieurs pays, puis d'afficher
les médailles obtenues sous forme de tableau ou d'histogramme.

Dépendances :
- pandas
- tkinter
- fichiers :
    - src/interface_graphique/histograme_question2.py
    - programmes/questions/questions_pandapython/question2_pandapython.py
    - donnees/athlete_events.csv
"""

import pandas as pd
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import sys
import os

# Ajouter le dossier src au sys.path pour l'import des modules personnalisés
script_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.abspath(os.path.join(script_dir, '..', '..'))
sys.path.insert(0, src_dir)

# Import des fonctions nécessaires à l'affichage et au traitement
from src.interface_graphique.histograme_question2 import afficher_histogramme_medailles
from programmes.questions.questions_pandapython.question2_pandapython import compter_medailles_par_pays

# Chargement des données nécessaires à l’analyse
df = pd.read_csv('donnees/athlete_events.csv')
df = df[['Team', 'Year', 'Event', 'Medal']]  # Garder uniquement les colonnes pertinentes


def lancer_interface_q2():
    """
    Lance l'interface graphique pour l'analyse des médailles olympiques.
    Permet de filtrer les résultats par année et pays, d'afficher les résultats,
    de générer un histogramme ou d'enregistrer les données filtrées.
    """
    # Création de la fenêtre principale
    root = tk.Tk()
    root.title("Analyse des Médailles Olympiques")
    root.geometry("700x600")
    root.configure(bg='#f0f0f0')

    # Frame principale
    main_frame = tk.Frame(root, bg='#f0f0f0')
    main_frame.pack(fill="both", expand=True, padx=10, pady=10)

    # Frame contenant les widgets de sélection et les boutons
    bouton_frame = tk.Frame(main_frame, bg='#f0f0f0')
    bouton_frame.grid(row=0, column=0, sticky="ew", pady=10)

    # Sélection de l’année
    tk.Label(bouton_frame, text="Sélectionnez une année :", bg='#f0f0f0').grid(row=0, column=0, padx=5)
    annees = sorted(df['Year'].unique())
    annee_var = tk.StringVar(value=str(annees[-1]))
    annee_menu = ttk.Combobox(bouton_frame, values=annees, textvariable=annee_var, state="readonly")
    annee_menu.grid(row=0, column=1, padx=5)

    # Sélection des pays
    tk.Label(bouton_frame, text="Sélectionnez le(s) pays (Ctrl+clic pour plusieurs) :", bg='#f0f0f0').grid(row=1, column=0, padx=5, sticky="n")
    pays_frame = tk.Frame(bouton_frame, bg='#f0f0f0')
    pays_frame.grid(row=1, column=1, columnspan=2, sticky="w")

    # Listbox avec scrollbar pour choisir les pays
    pays_scrollbar = tk.Scrollbar(pays_frame, orient="vertical")
    pays_listbox = tk.Listbox(pays_frame, selectmode='multiple', height=5, exportselection=False, yscrollcommand=pays_scrollbar.set)
    pays_scrollbar.config(command=pays_listbox.yview)
    pays_listbox.pack(side="left", fill="y")
    pays_scrollbar.pack(side="right", fill="y")

    # Mise à jour de la liste des pays selon l’année sélectionnée
    def maj_liste_pays(*args):
        pays_listbox.delete(0, tk.END)
        year = int(annee_var.get())
        pays = sorted(df[df['Year'] == year]['Team'].dropna().unique())
        pays.insert(0, 'all')  # Option "all" pour tout sélectionner
        for p in pays:
            pays_listbox.insert(tk.END, p)

    annee_menu.bind("<<ComboboxSelected>>", maj_liste_pays)
    maj_liste_pays()

    # Configuration du tableau de résultats
    columns = ['Team', 'Gold_inf', 'Silver_inf', 'Bronze_inf', 'Total_inf',
               'Gold_sup', 'Silver_sup', 'Bronze_sup', 'Total_sup']
    tree = ttk.Treeview(root, columns=columns, show='headings', height=15)
    for col in columns:
        tree.heading(col, text=col)
        tree.column(col, width=100)

    # Ajout d’un canvas pour faire défiler les résultats
    canvas = tk.Canvas(main_frame, bg='#f0f0f0')
    scrollbar = tk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
    canvas.configure(yscrollcommand=scrollbar.set)
    canvas.grid(row=1, column=0, sticky="nsew")
    scrollbar.grid(row=1, column=1, sticky="ns")

    result_frame = tk.Frame(canvas, bg='#f0f0f0')
    canvas.create_window((0, 0), window=result_frame, anchor="nw")
    tree.pack(in_=result_frame, padx=5, pady=5)

    def afficher_resultats():
        """Affiche les résultats des médailles selon les filtres sélectionnés."""
        annee = int(annee_var.get())
        selection = [pays_listbox.get(i) for i in pays_listbox.curselection()]
        team = 'all' if 'all' in selection or not selection else selection

        try:
            resultats = compter_medailles_par_pays(annee, team)
        except ValueError as e:
            messagebox.showerror("Erreur", str(e))
            return

        # Nettoyer les résultats précédents
        for i in tree.get_children():
            tree.delete(i)

        # Insérer les nouvelles données dans le tableau
        for _, row in resultats.iterrows():
            tree.insert('', tk.END, values=[str(row[col]) if col in row else '' for col in columns])

        result_frame.update_idletasks()
        canvas.config(scrollregion=canvas.bbox("all"))

    # Bouton pour afficher les résultats
    bouton_afficher = tk.Button(bouton_frame, text="Afficher les résultats", command=afficher_resultats, bg='#4CAF50', fg='white', relief="solid")
    bouton_afficher.grid(row=0, column=2, padx=10)

    # Bouton pour quitter l’application
    def quitter():
        root.destroy()

    bouton_quitter = tk.Button(bouton_frame, text="Quitter", command=quitter, bg='#FF6347', fg='white', relief="solid")
    bouton_quitter.grid(row=0, column=3, padx=10)

    # Bouton pour afficher l'histogramme
    def afficher_histogramme():
        """Affiche un histogramme des médailles pour les filtres sélectionnés."""
        annee = int(annee_var.get())
        selection = [pays_listbox.get(i) for i in pays_listbox.curselection()]
        team = 'all' if 'all' in selection or not selection else selection

        try:
            resultats = compter_medailles_par_pays(annee, team)
            afficher_histogramme_medailles(resultats)
        except ValueError as e:
            messagebox.showerror("Erreur", str(e))

    bouton_histogramme = tk.Button(bouton_frame, text="Afficher l'histogramme", command=afficher_histogramme, bg='#FFA500', fg='white', relief="solid")
    bouton_histogramme.grid(row=0, column=5, padx=10)

    # Bouton pour enregistrer les résultats dans un fichier CSV
    def enregistrer_resultats():
        """Sauvegarde les résultats filtrés dans un fichier CSV."""
        annee = int(annee_var.get())
        selection = [pays_listbox.get(i) for i in pays_listbox.curselection()]
        team = 'all' if 'all' in selection or not selection else selection

        try:
            resultats = compter_medailles_par_pays(annee, team)
        except ValueError as e:
            messagebox.showerror("Erreur", str(e))
            return

        fichier = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files", "*.csv")])
        if fichier:
            resultats.to_csv(fichier, index=False)
            messagebox.showinfo("Succès", "Les résultats ont été enregistrés avec succès!")

    bouton_enregistrer = tk.Button(bouton_frame, text="Enregistrer les résultats", command=enregistrer_resultats, bg='#007BFF', fg='white', relief="solid")
    bouton_enregistrer.grid(row=0, column=4, padx=10)

    # Configuration des proportions d’espace dans la fenêtre principale
    root.grid_rowconfigure(1, weight=1)
    root.grid_columnconfigure(0, weight=1)

    # Lancement de la boucle principale de l’interface
    root.mainloop()


if __name__ == "__main__":
    lancer_interface_q2()
