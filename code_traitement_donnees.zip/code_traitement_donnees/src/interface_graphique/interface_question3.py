import os
import sys
import pandas as pd
import tkinter as tk

# Ajouter explicitement le dossier src au sys.path
script_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.abspath(os.path.join(script_dir, '..', '..'))
sys.path.insert(0, src_dir)

from programmes.questions.questions_pandapython.question3_pandapython import trouver_athletes_ete_hiver

def charger_et_traiter_donnees():
    # Lire les fichiers
    donnees = pd.read_csv("donnees/athlete_events.csv")
    donnees = donnees[donnees["Medal"].notnull()]
    pays = pd.read_csv("donnees/noc_regions.csv")

    # Jointure avec les régions
    donnees_jo = pd.merge(donnees, pays[["NOC", "region"]], on="NOC", how="left")

    # Appel de la fonction de traitement
    athletes = trouver_athletes_ete_hiver(donnees_jo, fichier_excel="athletes_multi_saisons.xlsx")

    # Formatage du texte à afficher
    texte = "\n".join([f"{athlete}" for athlete in athletes])
    return texte

def lancer_interface_q3():
    # Création de l'interface graphique
    root = tk.Tk()
    root.title("Résultats des athlètes Olympiques")
    root.geometry("600x600")

    # Titre
    label_title = tk.Label(root, text="Athlètes Olympiques", font=("Helvetica", 16))
    label_title.pack(pady=10)

    # Zone de texte pour afficher les résultats
    label_resultat = tk.Label(root, text="", font=("Helvetica", 10), justify="left", wraplength=580)
    label_resultat.pack(pady=10)

    # Fonction à appeler au clic sur le bouton
    def afficher_resultats():
        resultat_text = charger_et_traiter_donnees()
        label_resultat.config(text=resultat_text)

    # Bouton pour afficher les résultats
    button_trouver = tk.Button(root, text="Afficher les résultats", command=afficher_resultats, font=("Helvetica", 12))
    button_trouver.pack(pady=20)

    # Bouton Quitter
    btn_quitter = tk.Button(root, text="Quitter", command=root.destroy, font=("Helvetica", 12))
    btn_quitter.pack(pady=20)


    root.mainloop()
