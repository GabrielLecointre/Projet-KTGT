"""
Interface graphique pour identifier les athlètes ayant participé aux Jeux Olympiques
d'été et d'hiver.

Ce module utilise une interface Tkinter pour charger les données des Jeux Olympiques
(athlete_events.csv) et des comités nationaux olympiques (noc_regions.csv), puis
affiche la liste des athlètes ayant participé à la fois aux JO d'été et d'hiver.
Il utilise une fonction de traitement externe et génère également un fichier Excel
avec les résultats.

Dépendances :
- pandas
- tkinter
- Fichiers nécessaires :
    - donnees/athlete_events.csv
    - donnees/noc_regions.csv
    - src/programmes/questions/questions_pandapython/question3_pandapython.py
"""

import os
import sys
import pandas as pd
import tkinter as tk

# Ajouter explicitement le dossier 'src' au sys.path pour permettre les imports personnalisés
script_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.abspath(os.path.join(script_dir, '..', '..'))
sys.path.insert(0, src_dir)

# Import de la fonction de traitement depuis le module externe
from programmes.questions.questions_pandapython.question3_pandapython import trouver_athletes_ete_hiver


def charger_et_traiter_donnees():
    """
    Charge les fichiers CSV, effectue une jointure sur les données des JO et des pays,
    puis appelle la fonction de traitement pour trouver les athlètes ayant participé aux
    JO d'été et d'hiver. Le résultat est exporté dans un fichier Excel.

    Returns:
        str: Texte formaté listant les athlètes trouvés.
    """
    # Lecture des résultats olympiques (en ne gardant que ceux avec des médailles)
    donnees = pd.read_csv("donnees/athlete_events.csv")
    donnees = donnees[donnees["Medal"].notnull()]

    # Lecture des correspondances entre NOC et régions/pays
    pays = pd.read_csv("donnees/noc_regions.csv")

    # Jointure des deux fichiers sur le code NOC
    donnees_jo = pd.merge(donnees, pays[["NOC", "region"]], on="NOC", how="left")

    # Appel de la fonction principale pour obtenir les athlètes été/hiver
    nom_fichier = "output/question_3/athletes_multi_saisons.xlsx"
    athletes = trouver_athletes_ete_hiver(donnees_jo, fichier_excel=nom_fichier)

    # Mise en forme du texte pour affichage
    texte = "\n".join([f"{athlete}" for athlete in athletes])
    return texte


def lancer_interface_q3():
    """
    Lance l'interface graphique Tkinter pour afficher la liste des athlètes ayant
    participé aux JO d'été et d'hiver.
    """
    # Création de la fenêtre principale
    root = tk.Tk()
    root.title("Résultats des athlètes Olympiques")
    root.geometry("600x600")

    # Titre de la fenêtre
    label_title = tk.Label(root, text="Athlètes Olympiques (été & hiver)", font=("Helvetica", 16))
    label_title.pack(pady=10)

    # Zone d'affichage des résultats
    label_resultat = tk.Label(root, text="", font=("Helvetica", 10), justify="left", wraplength=580)
    label_resultat.pack(pady=10)

    def afficher_resultats():
        """
        Fonction appelée lors du clic sur le bouton.
        Met à jour l'affichage avec les résultats de l'analyse.
        """
        resultat_text = charger_et_traiter_donnees()
        label_resultat.config(text=resultat_text)

    # Bouton pour lancer l'analyse
    button_trouver = tk.Button(root, text="Afficher les résultats", command=afficher_resultats, font=("Helvetica", 12))
    button_trouver.pack(pady=20)

    # Bouton pour fermer l'application
    btn_quitter = tk.Button(root, text="Quitter", command=root.destroy, font=("Helvetica", 12))
    btn_quitter.pack(pady=20)

    # Lancement de la boucle principale de l'interface
    root.mainloop()
