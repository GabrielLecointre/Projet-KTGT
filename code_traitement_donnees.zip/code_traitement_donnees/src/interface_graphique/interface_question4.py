from tkinter import messagebox
from tkinter import ttk  # Ajout de ttk pour utiliser Combobox
import tkinter as tk
import pandas as pd
import sys
import os

# Ajouter explicitement le dossier src au sys.path
script_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.abspath(os.path.join(script_dir, '..', '..'))
sys.path.insert(0, src_dir)

from programmes.questions.questions_pandapython.question4_pandapython import classement_jo

# Chargement des données
donnees = pd.read_csv("donnees/athlete_events.csv")
pays = pd.read_csv("donnees/noc_regions.csv")
donnees_jo = pd.merge(
    donnees,
    pays[["NOC", "region"]],
    on="NOC",
    how="left",
)

# Filtrer uniquement les JO d'été
donnees_jo = donnees_jo[(donnees_jo["Season"] == "Summer")]

# Extraire les années disponibles
annees_disponibles = sorted(donnees_jo["Year"].unique())


# Fonction pour afficher les résultats
def afficher_resultats():
    try:
        annee = int(combo_annee.get())
        nb_pays = 15
        classement = classement_jo(donnees_jo, annee, nb_pays)

        message = f"Classement des {nb_pays} premiers pays aux JO de {annee} :\n\n"
        for index, row in classement.iterrows():
            message += f"{index}: Or: {row['Gold']}, Argent: {row['Silver']}, Bronze: {row['Bronze']}, Total: {row['Total']} médailles\n"

        messagebox.showinfo(f"Résultats des JO de {annee}", message)
    except Exception as e:
        messagebox.showerror("Erreur", f"Une erreur est survenue : {str(e)}")


# Création de l'interface graphique
def lancer_interface_q4():
    global combo_annee

    root = tk.Tk()
    root.title("Classement des JO")

    label = tk.Label(root, text="Sélectionner une année pour afficher les résultats", font=("Arial", 14))
    label.pack(pady=20)

    combo_annee = ttk.Combobox(root, values=annees_disponibles, state="readonly", width=10)
    combo_annee.pack(pady=10)
    combo_annee.set(annees_disponibles[0])

    btn_afficher = tk.Button(root, text="Afficher les résultats", command=afficher_resultats)
    btn_afficher.pack(pady=10)

    btn_quitter = tk.Button(root, text="Quitter", command=root.destroy)
    btn_quitter.pack(pady=10)

    root.mainloop()

# Exécuter l'application
if __name__ == "__main__":
    lancer_interface_q4()
