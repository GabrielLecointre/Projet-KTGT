"""
Interface graphique pour afficher le classement des pays aux Jeux Olympiques d'été.

Ce module utilise Tkinter pour permettre à l'utilisateur de sélectionner une année
et visualiser le top 15 des pays classés par nombre de médailles (or, argent, bronze,
total).
Les données sont extraites des fichiers :
- athlete_events.csv (résultats des épreuves)
- noc_regions.csv (code des pays)

Dépendances :
- pandas
- tkinter (avec ttk)
- Fichier de traitement :
    - programmes/questions/questions_pandapython/question4_pandapython.py
"""

import os
import sys
import pandas as pd
import tkinter as tk
from tkinter import ttk, messagebox

# Ajouter le dossier 'src' au chemin Python pour l'import des modules personnalisés
script_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.abspath(os.path.join(script_dir, '..', '..'))
sys.path.insert(0, src_dir)

# Import de la fonction de traitement du classement
from programmes.questions.questions_pandapython.question4_pandapython import classement_jo

# Chargement des données CSV nécessaires
donnees = pd.read_csv("donnees/athlete_events.csv")
pays = pd.read_csv("donnees/noc_regions.csv")

# Jointure des données pour inclure les noms de pays
donnees_jo = pd.merge(
    donnees,
    pays[["NOC", "region"]],
    on="NOC",
    how="left"
)

# Filtrage pour ne garder que les Jeux Olympiques d'été
donnees_jo = donnees_jo[donnees_jo["Season"] == "Summer"]

# Extraire la liste des années disponibles pour les JO d'été
annees_disponibles = sorted(donnees_jo["Year"].unique())


def afficher_resultats():
    """
    Fonction appelée lors du clic sur le bouton 'Afficher les résultats'.
    Affiche une boîte de dialogue contenant le classement des 15 premiers pays
    pour l'année sélectionnée.
    """
    try:
        annee = int(combo_annee.get())  # Année sélectionnée
        nb_pays = 15                    # Nombre de pays à afficher dans le classement
        classement = classement_jo(donnees_jo, annee, nb_pays)

        # Construction du message à afficher
        message = f"Classement des {nb_pays} premiers pays aux JO de {annee} :\n\n"
        for index, row in classement.iterrows():
            message += (
                f"{index}: Or: {row['Gold']}, "
                f"Argent: {row['Silver']}, "
                f"Bronze: {row['Bronze']}, "
                f"Total: {row['Total']} médailles\n"
            )

        # Affichage des résultats dans une boîte de message
        messagebox.showinfo(f"Résultats des JO de {annee}", message)

    except Exception as e:
        # Gestion des erreurs (ex : année invalide ou problème de traitement)
        messagebox.showerror("Erreur", f"Une erreur est survenue : {str(e)}")


def lancer_interface_q4():
    """
    Crée et lance l'interface graphique Tkinter.
    Permet de sélectionner une année et d'afficher le classement correspondant.
    """
    global combo_annee

    # Création de la fenêtre principale
    root = tk.Tk()
    root.title("Classement des JO d'Été")
    root.geometry("400x250")

    # Étiquette d'instruction
    label = tk.Label(
        root,
        text="Sélectionner une année pour afficher les résultats",
        font=("Arial", 14)
    )
    label.pack(pady=20)

    # Menu déroulant pour la sélection d'année
    combo_annee = ttk.Combobox(
        root,
        values=annees_disponibles,
        state="readonly",
        width=10
    )
    combo_annee.pack(pady=10)
    combo_annee.set(annees_disponibles[0])  # Valeur par défaut

    # Bouton pour afficher les résultats
    btn_afficher = tk.Button(
        root,
        text="Afficher les résultats",
        command=afficher_resultats,
        font=("Arial", 12)
    )
    btn_afficher.pack(pady=10)

    # Bouton pour quitter l'application
    btn_quitter = tk.Button(
        root,
        text="Quitter",
        command=root.destroy,
        font=("Arial", 12)
    )
    btn_quitter.pack(pady=10)

    # Lancement de la boucle principale
    root.mainloop()


# Lancer l'interface si le script est exécuté directement
if __name__ == "__main__":
    lancer_interface_q4()
