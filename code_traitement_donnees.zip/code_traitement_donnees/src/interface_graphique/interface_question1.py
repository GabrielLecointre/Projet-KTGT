import tkinter as tk
from tkinter import ttk
import pandas as pd
import os
import sys

# === Configuration du chemin d'import ===
script_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.abspath(os.path.join(script_dir, '..', '..'))
sys.path.insert(0, src_dir)

# Import de la fonction de traitement
from programmes.questions.questions_pandapython.question1_pandapython import nb_medailles_athlete


def lancer_interface_q1():
    """
    Fonction principale qui lance l'interface graphique pour la sélection de l'année
    et de l'athlète, puis exécute une fonction pour afficher le nombre de médailles
    d'un athlète.

    Cette fonction :
    - Charge les données depuis un fichier CSV contenant des événements d'athlètes.
    - Crée une interface graphique avec des menus déroulants pour sélectionner une
    année et un athlète.
    - Affiche le résultat sous forme de message, incluant le nombre total de médailles
    de l'athlète sélectionné.
    """
    try:
        df = pd.read_csv('donnees/athlete_events.csv')
        df['Year'] = df['Year'].astype(int)
        all_years = sorted(df['Year'].unique())
        all_names = sorted(df['Name'].unique())
    except Exception as e:
        print(f"Erreur lors du chargement des données : {e}")
        return

    # === Création de la fenêtre ===
    fenetre = tk.Tk()
    fenetre.title("Question 1 - Médailles d'un athlète")
    fenetre.geometry("500x300")

    frame = tk.Frame(fenetre)
    frame.pack(padx=10, pady=10)

    # === Widgets ===
    tk.Label(frame, text="Sélectionnez une année :").grid(row=0, column=0, sticky="w", pady=5)
    annee_var = tk.StringVar()
    combo_annee = ttk.Combobox(frame, textvariable=annee_var, values=["Toutes"] + [str(a) for a in all_years])
    combo_annee.grid(row=0, column=1, pady=5)
    combo_annee.set("Toutes")

    tk.Label(frame, text="Sélectionnez un athlète :").grid(row=1, column=0, sticky="w", pady=5)
    athlete_var = tk.StringVar()
    combo_athlete = ttk.Combobox(frame, textvariable=athlete_var, values=all_names)  # Suppression de "Tous"
    combo_athlete.grid(row=1, column=1, pady=5)

    label_resultat = tk.Label(frame, text="", wraplength=450, fg="blue", justify="left")
    label_resultat.grid(row=3, column=0, columnspan=2, pady=15)


    # === Fonction de mise à jour des athlètes seulement quand l’année change ===
    def mettre_a_jour_athletes(*args):
        """
        Fonction qui met à jour la liste des athlètes dans le combobox en fonction
        de l'année sélectionnée.

        Si l'année sélectionnée est "Toutes", tous les athlètes sont affichés. Si une
        année spécifique est sélectionnée, seuls les athlètes ayant participé à
        cette année sont affichés.
        """
        annee = annee_var.get()
        if annee == "Toutes":
            noms = sorted(df['Name'].unique())
        elif annee.isdigit():  # Vérification si l'année sélectionnée est un entier valide
            noms = sorted(df[df['Year'] == int(annee)]['Name'].unique())
        else:
            noms = []  # Si la valeur de l'année est invalide, on ne charge aucun athlète
        combo_athlete['values'] = noms
        if noms:
            athlete_var.set(noms[0])  # Si des athlètes existent, sélectionne le premier par défaut
        else:
            athlete_var.set("")  # Si aucun athlète n'est disponible, on vide la sélection


    # === Fonction d'exécution ===
    def executer():
        """
        Fonction qui exécute le calcul du nombre de médailles pour l'athlète sélectionné.

        Elle récupère le nom de l'athlète et l'année sélectionnée dans l'interface, puis appelle la fonction
        `nb_medailles_athlete` pour obtenir le nombre de médailles. Le résultat est affiché dans l'interface.
        """
        nom = athlete_var.get().strip()
        annee = annee_var.get()

        if not nom:
            label_resultat.config(text="Veuillez sélectionner un athlète.")
            return

        try:
            annee_val = None if annee == "Toutes" else int(annee)
            resultat = nb_medailles_athlete(nom, annee_val)
            total = resultat.get("total_medailles", 0)
            label_resultat.config(text=f"{total} médaille(s) trouvée(s). Voir la console et le fichier Excel.")
        except Exception as e:
            label_resultat.config(text=f"Erreur : {str(e)}")

    # Écouter l'événement de changement de sélection dans le combobox année
    combo_annee.bind("<<ComboboxSelected>>", mettre_a_jour_athletes)

    # === Boutons ===
    tk.Button(frame, text="Exécuter", command=executer).grid(row=4, column=0, pady=10)
    tk.Button(frame, text="Quitter", command=fenetre.destroy).grid(row=4, column=1, pady=10)

    fenetre.mainloop()


# Lancement
if __name__ == "__main__":
    lancer_interface_q1()
