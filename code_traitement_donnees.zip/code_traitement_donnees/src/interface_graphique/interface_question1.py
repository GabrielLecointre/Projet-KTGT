import sys
import os
import tkinter as tk

# Ajouter explicitement le dossier src au sys.path
script_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.abspath(os.path.join(script_dir, '..', '..'))
sys.path.insert(0, src_dir)

from programmes.questions.questions_pandapython.question1_pandapython import nb_medailles_athlete  # La fonction doit retourner un résultat (str)


def lancer_interface_q1():
    """
    Affiche une fenêtre pour la question 1 où l'utilisateur entre un nom d'athlète et une année.
    """
    fenetre_question = tk.Tk()
    fenetre_question.title("Question 1 - Médailles d'un athlète")
    fenetre_question.geometry("400x300")

    # Création d'un cadre pour les boutons
    frame_boutons = tk.Frame(fenetre_question)
    frame_boutons.pack(side="top", fill="x", pady=10)

    # Création d'un Canvas avec une barre de défilement
    canvas = tk.Canvas(fenetre_question)
    scrollbar = tk.Scrollbar(fenetre_question, orient="vertical", command=canvas.yview)
    canvas.configure(yscrollcommand=scrollbar.set)

    # Frame à l'intérieur du Canvas qui contient tous les widgets
    frame = tk.Frame(canvas)

    # Ajout de la barre de défilement et du canvas
    scrollbar.pack(side="right", fill="y")
    canvas.pack(side="left", fill="both", expand=True)

    # Placement du frame sur le canvas
    canvas.create_window((0, 0), window=frame, anchor="nw")

    # Interface utilisateur
    tk.Label(frame, text="Nom de l'athlète :").pack(pady=5)
    entry_nom = tk.Entry(frame)
    entry_nom.pack(pady=5)

    tk.Label(frame, text="Année (optionnelle) :").pack(pady=5)
    entry_annee = tk.Entry(frame)
    entry_annee.pack(pady=5)

    # Label où sera affiché le résultat
    label_resultat = tk.Label(frame, text="", wraplength=350, justify="left", fg="blue")
    label_resultat.pack(pady=10)

    def executer():
        nom = entry_nom.get().strip()
        annee_str = entry_annee.get().strip()

        if not nom:
            label_resultat.config(text="Veuillez entrer un nom.")
            return

        try:
            annee = int(annee_str) if annee_str else None
            # Appel de la fonction : elle doit retourner une chaîne de caractères
            resultat = nb_medailles_athlete(nom, annee)
            label_resultat.config(text=f"Résultat : {resultat}")
        except ValueError:
            label_resultat.config(text="Année invalide. Utilisez un nombre entier.")
        except Exception as e:
            label_resultat.config(text=f"Erreur : {str(e)}")

    # Boutons
    tk.Button(frame_boutons, text="Exécuter", command=executer).pack(side="left", padx=10)
    tk.Button(frame_boutons, text="Quitter", command=fenetre_question.destroy).pack(side="left", padx=10)

    # Mise à jour de la région de défilement pour que le contenu soit correctement pris en compte
    fenetre_question.update_idletasks()  # Met à jour les tailles pour calculer correctement la zone de défilement
    canvas.config(scrollregion=canvas.bbox("all"))  # Ajuste la région de défilement

    fenetre_question.mainloop()


if __name__ == "__main__":
    lancer_interface_q1()
