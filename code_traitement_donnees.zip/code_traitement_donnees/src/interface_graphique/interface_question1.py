import tkinter as tk
import pandas as pd
import os
import sys

# Ajouter explicitement le dossier src au sys.path
script_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.abspath(os.path.join(script_dir, '..', '..'))
sys.path.insert(0, src_dir)

from programmes.questions.questions_pandapython.question1_pandapython import nb_medailles_athlete


def lancer_interface_q1():
    """
    Affiche une fenêtre pour la question 1 où l'utilisateur entre un nom d'athlète
    et sélectionne une année via un menu déroulant.
    """
    # Charger les années uniques à partir du fichier CSV
    try:
        df = pd.read_csv('donnees/athlete_events.csv')
        annees_disponibles = sorted(df['Year'].dropna().unique())
        annees_options = ["Toutes"] + [str(int(a)) for a in annees_disponibles]
    except Exception as e:
        print(f"Erreur lors du chargement des années : {e}")
        annees_options = ["Toutes"]

    fenetre_question = tk.Tk()
    fenetre_question.title("Question 1 - Médailles d'un athlète")
    fenetre_question.geometry("400x300")

    # Création d'un cadre pour les boutons
    frame_boutons = tk.Frame(fenetre_question)
    frame_boutons.pack(side="top", fill="x", pady=10)

    # Création d'un Canvas avec une barre de défilement
    canvas = tk.Canvas(fenetre_question)
    scrollbar = tk.Scrollbar(fenetre_question, orient="vertical", command=canvas.yview)
    canvas.configure(yscrollcommand=scrollbar.set)

    frame = tk.Frame(canvas)

    scrollbar.pack(side="right", fill="y")
    canvas.pack(side="left", fill="both", expand=True)
    canvas.create_window((0, 0), window=frame, anchor="nw")

    # Interface utilisateur
    tk.Label(frame, text="Nom de l'athlète :").pack(pady=5)
    entry_nom = tk.Entry(frame)
    entry_nom.pack(pady=5)

    tk.Label(frame, text="Sélectionnez une année :").pack(pady=5)
    annee_var = tk.StringVar(value="Toutes")
    menu_annee = tk.OptionMenu(frame, annee_var, *annees_options)
    menu_annee.pack(pady=5)

    label_resultat = tk.Label(frame, text="", wraplength=350, justify="left", fg="blue")
    label_resultat.pack(pady=10)

    def executer():
        nom = entry_nom.get().strip()
        annee_selectionnee = annee_var.get()

        if not nom:
            label_resultat.config(text="Veuillez entrer un nom.")
            return

        try:
            annee = None if annee_selectionnee == "Toutes" else int(annee_selectionnee)
            resultat = nb_medailles_athlete(nom, annee)
            total = resultat.get("total_medailles", 0)
            label_resultat.config(text=f"{total} médaille(s) trouvée(s). Voir la console et le fichier Excel.")
        except ValueError:
            label_resultat.config(text="Erreur : année invalide.")
        except Exception as e:
            label_resultat.config(text=f"Erreur : {str(e)}")

    tk.Button(frame_boutons, text="Exécuter", command=executer).pack(side="left", padx=10)
    tk.Button(frame_boutons, text="Quitter", command=fenetre_question.destroy).pack(side="left", padx=10)

    fenetre_question.update_idletasks()
    canvas.config(scrollregion=canvas.bbox("all"))

    fenetre_question.mainloop()


if __name__ == "__main__":
    lancer_interface_q1()
