import tkinter as tk
import pandas as pd
import os
import sys

# === Configuration du chemin d'import ===

# Récupère le chemin du répertoire courant (celui du script)
script_dir = os.path.dirname(os.path.abspath(__file__))

# Remonte deux niveaux dans l'arborescence pour atteindre le dossier racine du projet
src_dir = os.path.abspath(os.path.join(script_dir, '..', '..'))

# Ajoute ce chemin au système pour permettre les imports de modules du projet
sys.path.insert(0, src_dir)

# Import de la fonction de traitement de la question 1
from programmes.questions.questions_pandapython.question1_pandapython import nb_medailles_athlete


def lancer_interface_q1():
    """
    Affiche une interface graphique avec Tkinter pour interroger le nombre
    de médailles d’un athlète donné, pour une année choisie (ou toutes années).
    """

    # === Chargement des années disponibles dans les données ===
    try:
        df = pd.read_csv('donnees/athlete_events.csv')
        annees_disponibles = sorted(df['Year'].dropna().unique())
        annees_options = ["Toutes"] + [str(int(a)) for a in annees_disponibles]
    except Exception as e:
        print(f"Erreur lors du chargement des années : {e}")
        annees_options = ["Toutes"]

    # === Création de la fenêtre principale ===
    fenetre_question = tk.Tk()
    fenetre_question.title("Question 1 - Médailles d'un athlète")
    fenetre_question.geometry("400x300")

    # Cadre pour contenir les boutons (Exécuter / Quitter)
    frame_boutons = tk.Frame(fenetre_question)
    frame_boutons.pack(side="top", fill="x", pady=10)

    # Ajout d'un Canvas avec une barre de défilement verticale
    canvas = tk.Canvas(fenetre_question)
    scrollbar = tk.Scrollbar(fenetre_question, orient="vertical", command=canvas.yview)
    canvas.configure(yscrollcommand=scrollbar.set)

    # Frame intégrée dans le Canvas pour recevoir les éléments
    frame = tk.Frame(canvas)

    scrollbar.pack(side="right", fill="y")
    canvas.pack(side="left", fill="both", expand=True)
    canvas.create_window((0, 0), window=frame, anchor="nw")

    # === Éléments de l'interface utilisateur ===

    # Zone de saisie pour le nom de l'athlète
    tk.Label(frame, text="Nom de l'athlète :").pack(pady=5)
    entry_nom = tk.Entry(frame)
    entry_nom.pack(pady=5)

    # Menu déroulant pour sélectionner une année
    tk.Label(frame, text="Sélectionnez une année :").pack(pady=5)
    annee_var = tk.StringVar(value="Toutes")
    menu_annee = tk.OptionMenu(frame, annee_var, *annees_options)
    menu_annee.pack(pady=5)

    # Zone d’affichage du résultat
    label_resultat = tk.Label(frame, text="", wraplength=350, justify="left", fg="blue")
    label_resultat.pack(pady=10)

    # === Fonction exécutée lors du clic sur "Exécuter" ===
    def executer():
        nom = entry_nom.get().strip()  # Récupère et nettoie le nom saisi
        annee_selectionnee = annee_var.get()

        if not nom:
            label_resultat.config(text="Veuillez entrer un nom.")
            return

        try:
            # Si l'utilisateur a choisi "Toutes", on passe None comme année
            annee = None if annee_selectionnee == "Toutes" else int(annee_selectionnee)

            # Appelle la fonction d’analyse
            resultat = nb_medailles_athlete(nom, annee)

            # Affiche le résultat dans le label
            total = resultat.get("total_medailles", 0)
            label_resultat.config(text=f"{total} médaille(s) trouvée(s). Voir la console et le fichier Excel.")
        except ValueError:
            label_resultat.config(text="Erreur : année invalide.")
        except Exception as e:
            label_resultat.config(text=f"Erreur : {str(e)}")

    # Boutons de contrôle
    tk.Button(frame_boutons, text="Exécuter", command=executer).pack(side="left", padx=10)
    tk.Button(frame_boutons, text="Quitter", command=fenetre_question.destroy).pack(side="left", padx=10)

    # Met à jour la zone de défilement en fonction du contenu
    fenetre_question.update_idletasks()
    canvas.config(scrollregion=canvas.bbox("all"))

    # Lancement de la boucle principale de l’interface
    fenetre_question.mainloop()


# === Lancement direct si ce fichier est exécuté en tant que script principal ===
if __name__ == "__main__":
    lancer_interface_q1()
