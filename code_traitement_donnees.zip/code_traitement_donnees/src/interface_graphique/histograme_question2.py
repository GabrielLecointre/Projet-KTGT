'''
Cette histogramme est affichée via l'interface graphique
il répond de manière visuelle à la question en affichant les bornes sup et inf de
des médailles du top5 des pays des jeux olympique de 2016
'''
import pandas as pd
import sys
import os
import matplotlib.pyplot as plt

# === Préparation de l'environnement ===

# Récupère le répertoire du script en cours
script_dir = os.path.dirname(os.path.abspath(__file__))

# Remonte deux niveaux pour accéder au dossier 'src' (où se trouve le module à importer)
src_dir = os.path.abspath(os.path.join(script_dir, '..', '..'))

# Ajoute ce chemin au système pour permettre l'import de modules externes
sys.path.insert(0, src_dir)

# Import de la fonction principale d'analyse des médailles (après ajout du bon chemin)
from programmes.questions.questions_pandapython.question2_pandapython import compter_medailles_par_pays

# Vérification que le chemin a bien été ajouté
print("Chemins dans sys.path:", sys.path)

# === Chargement des données ===

# Chargement du fichier CSV contenant les données des athlètes
df = pd.read_csv('donnees/athlete_events.csv')

# Sélection des colonnes pertinentes pour notre analyse
df = df[['Team', 'Year', 'Event', 'Medal']]

# === Fonction de visualisation ===


def afficher_histogramme_medailles(df, n=5):
    """
    Affiche un histogramme comparant les bornes inférieure et supérieure
    du nombre de médailles pour les n premiers pays selon le total supérieur.

    Parameters
    ----------
    df : pd.DataFrame
        Le DataFrame contenant au minimum les colonnes 'Total_inf' et 'Total_sup'.
        L'index doit contenir les noms des pays.

    n : int
        Le nombre de pays à afficher (top n selon Total_sup).
    """
    # Vérifie que les colonnes nécessaires sont bien présentes
    if not {'Total_inf', 'Total_sup'}.issubset(df.columns):
        raise ValueError("Le DataFrame doit contenir les colonnes 'Total_inf' et 'Total_sup'.")

    # Trie les pays selon leur total supérieur de médailles, et garde les n premiers
    df_top = df.sort_values(by='Total_sup', ascending=False).head(n)

    # Récupère les noms des pays et l'index pour l'affichage
    teams = df_top.index
    x = range(len(teams))  # positions x pour les barres
    bar_width = 0.35       # largeur des barres

    # Création de la figure
    plt.figure(figsize=(10, 6))

    # Tracé de la barre pour le total inférieur
    plt.bar(x, df_top['Total_inf'], width=bar_width, label='Borne inférieure', color='skyblue')

    # Tracé de la barre pour le total supérieur, légèrement décalée à droite
    plt.bar([i + bar_width for i in x], df_top['Total_sup'], width=bar_width, label='Borne supérieure', color='orange')

    # Mise en forme de l'histogramme
    plt.xlabel('Pays')
    plt.ylabel('Nombre de médailles')
    plt.title(f'Top {n} nations - Médailles JO 2016 (bornes inférieure et supérieure)')
    plt.xticks([i + bar_width / 2 for i in x], teams, rotation=30)
    plt.legend()
    plt.tight_layout()

    # === Sauvegarde de l'image ===

    # Répertoire et chemin de sauvegarde
    save_dir = "output/question_2"
    save_path = os.path.join(save_dir, "histo_question2.jpg")

    # Enregistre le graphique en haute résolution
    plt.savefig(save_path, format='jpg', dpi=300)
    print(f"Histogramme sauvegardé dans : {save_path}")

    # Affiche la figure à l'écran
    plt.show()
