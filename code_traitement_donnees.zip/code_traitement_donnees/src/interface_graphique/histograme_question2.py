import pandas as pd
import sys
import os
import matplotlib.pyplot as plt

# Ajouter explicitement le dossier src au sys.path
# Obtenir le répertoire courant du script
script_dir = os.path.dirname(os.path.abspath(__file__))
# Ajouter le dossier src (parent du dossier actuel) au sys.path
src_dir = os.path.abspath(os.path.join(script_dir, '..', '..'))
sys.path.insert(0, src_dir)

# Import après avoir modifié sys.path
from programmes.questions.questions_pandapython.question2_pandapython import compter_medailles_par_pays

# Vérifier sys.path pour s'assurer que le chemin correct est ajouté
print("Chemins dans sys.path:", sys.path)

# Charger les données (assurez-vous que le fichier est au bon endroit)
df = pd.read_csv('donnees/athlete_events.csv')
df = df[['Team', 'Year', 'Event', 'Medal']]


def afficher_histogramme_medailles(df, n=5):
    """
    Affiche un histogramme comparant les bornes inférieure et supérieure
    du nombre de médailles pour les n premiers pays selon Total_sup.
    """
    if not {'Total_inf', 'Total_sup'}.issubset(df.columns):
        raise ValueError("Le DataFrame doit contenir les colonnes 'Total_inf' et 'Total_sup'.")

    df_top = df.sort_values(by='Total_sup', ascending=False).head(n)
    teams = df_top.index
    x = range(len(teams))
    bar_width = 0.35

    plt.figure(figsize=(10, 6))
    plt.bar(x, df_top['Total_inf'], width=bar_width, label='Borne inférieure', color='skyblue')
    plt.bar([i + bar_width for i in x], df_top['Total_sup'], width=bar_width, label='Borne supérieure', color='orange')

    plt.xlabel('Pays')
    plt.ylabel('Nombre de médailles')
    plt.title(f'Top {n} nations - Médailles JO 2016 (bornes inférieure et supérieure)')
    plt.xticks([i + bar_width / 2 for i in x], teams, rotation=30)
    plt.legend()
    plt.tight_layout()

    # Sauvegarde de la figure
    save_dir = "output/question_2"
    save_path = os.path.join(save_dir, "histo_question2.jpg")
    plt.savefig(save_path, format='jpg', dpi=300)
    print(f"Histogramme sauvegardé dans : {save_path}")
    plt.show()
