
****************************************************
* Projet d'analyse des données des jeux olympiques *
****************************************************

Description
-----------
Ce projet vise à analyser les données des Jeux Olympiques modernes à l'aide de
différentes méthodes de traitement de données.

Il inclut l'analyse des performances des athlètes, la classification des épreuves
sportives en fonction des caractéristiques physiques des athlètes, et la comparaison
des performances entre différentes nations au cours des différentes éditions des Jeux.

Le code est divisé en plusieurs modules, chacun ayant une fonction spécifique,
allant de la gestion des données brutes à l'application d'algorithmes de classification.
Le projet utilise des bibliothèques comme Pandas, NumPy, Scikit-learn, et Tkinter pour
l'analyse et l'interface graphique.

Structure du projet
-------------------
Le projet est organisé en plusieurs répertoires pour une meilleure gestion et modularité du code :

/code_traitement_donnees/
│
├── donnees/                  # Contient les fichiers de données brutes (CSV)
│   ├── athlete_events.csv    # Données des athlètes aux JO
│   └── noc_regions.csv       # Codes des Comités Nationaux Olympiques
│
├── programmes/               # Contient les scripts pour le traitement des données et l'analyse
│   ├── classification/       # Modules pour la classification par K-Means
│   ├── questions/            # Modules pour les analyses de données (statistiques, visualisation, etc.)
│
├── src/                      # Code source principal
│   ├── main.py               # Script principal de l'application
│   ├── interface_graphique/  # Code pour l'interface graphique avec Tkinter
│   └── tests/                # Scripts de test pour comparer les différentes implémentations
│
├── output/                   # Répertoire où sont stockées les sorties des analyses (résultats, visualisations)
│
└── README.md                 # Ce fichier

Installation
------------
Lancer le fichier main.py du dossier /src
Une interface graphique s'affichera avec un menu déroulant
Il suffit de sélectionner et de remplir les champs

Prérequis
---------
Avant d'exécuter ce projet, assurez-vous d'avoir installé les dépendances suivantes :

    Python 3.x
    Pandas
    NumPy
    Scikit-learn
    Matplotlib (pour les visualisations)
    Tkinter (pour l'interface graphique)

Auteurs
-------

Téodora
Gabriel
Tual
Khalid